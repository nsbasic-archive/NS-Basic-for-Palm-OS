/**
    NSBPNO68K.h
    
    Global information for the 68K portion of NSBasic 
    to use the PNO.
    
    Should be included 68K code but not PNO code.
    
    Eric Pepke Sep 20, 2003
  */
  
