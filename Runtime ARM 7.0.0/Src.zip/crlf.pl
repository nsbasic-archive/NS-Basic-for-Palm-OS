while (<>)
{
    s/\r/\n/g;
    print;
}