/**
    NSBPNOGlue.cpp
    Glue for 68K functions
    Eric Pepke
    23 Sep 2003
  */

#include "NSBPNOGlue.h"