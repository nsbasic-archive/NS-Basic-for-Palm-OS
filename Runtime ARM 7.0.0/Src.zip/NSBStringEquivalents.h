// EMP
// Equivalents for some PNO string functions

#define StrLen(s) strlen(s)
#define StrCopy(d, s) strcpy(d, s)
#define StrCat(d, s) strcat(d, s)
#define StrNCat(d, s, n) strncat(d, s, n)
#define StrChr(s, c) strchr(s, c)