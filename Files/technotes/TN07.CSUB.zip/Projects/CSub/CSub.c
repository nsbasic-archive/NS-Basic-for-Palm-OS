//
//                     C S u b
//
//  Version: 1.0
//  Date:    March 29, 2001
//  Author:  Ron Glowka, Austin, Texas, U.S.A.
//

#include <PalmOS.h>

#define appFileCreator			'RdG0'
#define appVersionNum           0x00
#define appPrefID               0x00
#define appPrefVersionNum       0x00

//
//  CAUTION:  NEVER, EVER, use Globals in this
//            type of "C" subroutine program!

//
//               A d d I n t E l e m e n t
//
static void AddIntElement(char *str, int nbr, char *delimiter) {
    char nbrStr[32];
    
    StrIToA(nbrStr, nbr);
    StrCat(str, nbrStr);
    StrCat(str, delimiter);
}

//
//              G e t F o r m A n d F i e l d
//
static int GetFormAndField(FormType **activeForm, UInt16 *fieldIndex, 
                           FieldType **fieldPtr) {
    *activeForm = FrmGetActiveForm();
    if (*activeForm != NULL) {
        *fieldIndex = FrmGetFocus(*activeForm);
        if (*fieldIndex != noFocus) {
            *fieldPtr = (FieldType *) FrmGetObjectPtr(*activeForm, *fieldIndex);
            return 1;
        }
    }
    return 0;
}

//
//              S a v e P r e f e r e n c e s
//
static void SavePreferences(char *data) {
    PrefSetAppPreferences(appFileCreator, appPrefID, appPrefVersionNum,
                          data, StrLen(data) + 1, false);
}

//
//                 P i l o t M a i n
//
UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
    Err        error = 0;
    char       returnData[81];
    FormType   *activeForm;
    UInt16     fieldIndex;
    FieldType  *fieldPtr;
    char       *fieldTextPtr;
    UInt16     selectionStart;
    UInt16     selectionEnd;
    UInt32     status;
    

    status = 0;
    switch (cmd) {
        case sysAppLaunchCmdNormalLaunch:
            returnData[0] = '\0';
            if (!StrCaselessCompare(cmdPBP, "FldCopy")) {
                if (GetFormAndField(&activeForm, &fieldIndex, &fieldPtr)) {
                    FldCopy(fieldPtr);
                }
            }
            else if (!StrCaselessCompare(cmdPBP, "FldPaste")) {
                if (GetFormAndField(&activeForm, &fieldIndex, &fieldPtr)) {
                    FldPaste(fieldPtr);
                }
            }
            else if (!StrCaselessCompare(cmdPBP, "FldGetSelection")) {
                if (GetFormAndField(&activeForm, &fieldIndex, &fieldPtr)) {
                    FldGetSelection(fieldPtr, &selectionStart, &selectionEnd);
                    AddIntElement(returnData, selectionStart, ";");
                    AddIntElement(returnData, selectionEnd, ";");
                }
           }
           else if (!StrCaselessCompare(cmdPBP, "newFldCopy")) {
                if (GetFormAndField(&activeForm, &fieldIndex, &fieldPtr)) {
                    FldGetSelection(fieldPtr, &selectionStart, &selectionEnd);
                    if (selectionStart == selectionEnd) {
                        fieldTextPtr = FldGetTextPtr(fieldPtr);
                        ClipboardAddItem(clipboardText, fieldTextPtr, 
                                         StrLen(fieldTextPtr));
                    }
                    else
                        FldCopy(fieldPtr);
                }
            }
            else {
                StrCopy(returnData, "Unrecognized command : ");
                StrCat(returnData, cmdPBP);
                status = 1;
            }
            SavePreferences(returnData);
            break;
    }

    return status;
}

