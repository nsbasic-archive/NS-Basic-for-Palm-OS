README.TXT

This directory contains five files/folders:

NSBSymbolLib.inf is the setup file for the library. Put in nsbasic\Lib.
NSBSymbolLib.prc is the downloadable Symbol library. Put in nsbasic\lib.
Symbol.prj is the NSBasic project used to test it. Put in nsbasic\Projects.
ReleaseNotes.txt is the release notes for this version.
README.TXT is this file.