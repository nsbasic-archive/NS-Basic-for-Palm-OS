#define	kOffset		(2*50)						// NOTE: This is empirical!!!!!!
