@GotoNSBTreoLibOpen:
	JMP 		NSBTreoLibOpen
@GotoNSBTreoLibClose:
	JMP 		NSBTreoLibClose
@GotoNSBTreoLibSleep:
	JMP 		NSBTreoLibSleep
@GotoNSBTreoLibWake:
	JMP 		NSBTreoLibWake
@GotoPhoneOn:
	JMP 		PhoneOn
@GotoSignalQuality:
	JMP 		SignalQuality
@GotoPhoneType:
	JMP 		PhoneType
@GotoPhoneReady:
	JMP 		PhoneReady
@GotoMainNumber:
	JMP 		MainNumber
@GotoNetworkAvailable:
	JMP 		NetworkAvailable
@GotoCallWaiting:
	JMP 		CallWaiting
@GotoCallWaitingSet:
	JMP 		CallWaitingSet
@GotoOperatorCurName:
	JMP 		OperatorCurName
@GotoOperatorCurID:
	JMP 		OperatorCurID
@GotoProvider:
	JMP 		Provider
@GotoOperatorCount:
	JMP 		OperatorCount
@GotoOperatorName:
	JMP 		OperatorName
@GotoOperator:
	JMP 		Operator
@GotoBookCount:
	JMP 		BookCount
@GotoBookFirstName:
	JMP 		BookFirstName
@GotoBookLastName:
	JMP 		BookLastName
@GotoBookPhoneNumber:
	JMP 		BookPhoneNumber
@GotoDialPhone:
	JMP 		DialPhone
@GotoSendSMSMessage:
	JMP 		SendSMSMessage
@GotoSendEMail:
	JMP 		SendEMail
@GotoBrowse:
	JMP 		Browse
@GotoBookReload:
	JMP 		BookReload
@GotoPhoneTurnOn:
	JMP 		PhoneTurnOn
@GotoTCPIPDropConnection:
	JMP 		TCPIPDropConnection
@GotoVibrate:
	JMP 		Vibrate
@GotoBlink:
	JMP 		Blink
@GotoRoaming:
	JMP 		Roaming
@GotoSoftware:
	JMP 		Software
@GotoHardware:
	JMP 		Hardware
@GotoProductName:
	JMP 		ProductName
@GotoSerialNumber:
	JMP 		SerialNumber
@GotoCarrierID:
	JMP 		CarrierID
@GotoProductRevision:
	JMP 		ProductRevision
@GotoROM:
	JMP 		ROM
@GotoFirmware:
	JMP 		Firmware
@GotoHTTPOpen:
	JMP 		HTTPOpen
@GotoHTTPClose:
	JMP 		HTTPClose
@GotoHTTPSendRequest:
	JMP 		HTTPSendRequest
@GotoKeyboardLocked:
	JMP 		KeyboardLocked
@GotoKeyboardLock:
	JMP 		KeyboardLock
@GotoHTTPGetHeader:
	JMP 		HTTPGetHeader
@GotoHTTPRead:
	JMP 		HTTPRead
@GotoHTTPSendPostRequest:
	JMP 		HTTPSendPostRequest
@GotoHTTPEnd:
	JMP 		HTTPEnd
