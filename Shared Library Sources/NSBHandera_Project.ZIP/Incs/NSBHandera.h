#ifndef __THIS_LIB_H__
#define __THIS_LIB_H__


#ifdef BUILDING_THIS_LIB
	#define THIS_LIB_TRAP(trapNum)
#else
	#define THIS_LIB_TRAP(trapNum) SYS_TRAP(trapNum)
#endif


// Palm OS common definitions
#include <PalmTypes.h>
#include <SystemResources.h>


/********************************************************************
 * Creator ID, Type, and Name of THIS Shared Library
 ********************************************************************/
#define		THIS_LibCreatorID	'NSBh'
#define		THIS_LibTypeID		'libr'
#define		THIS_LibName		"NSBHandera.lib"		


/************************************************************
 * Library result codes:
 * (appErrorClass is reserved for 3rd party apps/libraries.
 * It is defined in SystemMgr.h)
 *************************************************************/

#define THIS_ErrParam		(appErrorClass | 1)		// invalid parameter
#define THIS_ErrNotOpen 	(appErrorClass | 2)		// library is not open
#define THIS_ErrStillOpen	(appErrorClass | 3)		// returned from THIS_LibClose() if
													// the library is still open by others
#define THIS_ErrMemory		(appErrorClass | 4)		// memory error occurred


//-----------------------------------------------------------------------------
//   Library function trap ID's:
//   Each library call gets a trap number.
//   THIS_TrapXXXX serves as an index into the library's dispatch
//   table.  The constant sysLibTrapCustom is the first available
//   trap number after the system predefined library traps Open,
//   Close, Sleep, & Wake.
//
//   WARNING!!! The order of these traps MUST match the order of 
//   the dispatch table in 'THIS_Lib'Dispatch.c!!!
//-----------------------------------------------------------------------------

typedef enum {
    // Version 1.0 functions:
	THIS_TrapVersion = sysLibTrapCustom,
	THIS_TrapCompileInfo,
	THIS_TrapAudioAdjVolumeSupported,
	THIS_TrapAudioDTMFSupported,
	THIS_TrapAudioGetMasterVolume,
	THIS_TrapAudioGetMute,
	THIS_TrapAudioPlayDTMFChar,
	THIS_TrapAudioPlayDTMFStr,
	THIS_TrapAudioPlayWaveSupported,
	THIS_TrapAudioRecordWaveSupported,
	THIS_TrapAudioSetMasterVolume,
	THIS_TrapAudioSetMute,
	THIS_TrapAudioVolumeDlg,
	THIS_TrapSilkGetGraffitiPersistence,
	THIS_TrapSilkMaximizeWindow,
	THIS_TrapSilkMinimizeWindow,
	THIS_TrapSilkSetGraffitiPersistence,
	THIS_TrapSilkWindowMinimized,
	THIS_TrapSizeForm,
	THIS_TrapVgaBaseToVgaFont,
	THIS_TrapVgaFontSelect,
	THIS_TrapVgaFrmModify,
	THIS_TrapVgaFrmGetTitleHeight,
	THIS_TrapVgaGetScreenMode,
	THIS_TrapVgaGetScreenOffset,
	THIS_TrapVgaGetScreenRotation,
	THIS_TrapVgaGetScreenState,
	THIS_TrapVgaIsVgaFont,
	THIS_TrapVgaRestoreScreenState,
	THIS_TrapVgaRotateSelect,
	THIS_TrapVgaSaveScreenState,
	THIS_TrapVgaSetScreenMode,
	THIS_TrapVgaSetScreenState,
	THIS_TrapVgaVgaToBaseFont,
	THIS_TrapVgaWinDrawBitmapExpanded,
	// Version 1.1 functions:
	
	THIS_TrapLast
	} THIS_TrapEnum;


/********************************************************************
 * API Prototypes
 ********************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

//--------------------------------------------------
// Custom library API functions
//--------------------------------------------------
	
/***************************************************
 *             Version 1.0 Functions:
 ***************************************************/
 
extern Err THIS_Version(UInt16 refNum, double *version)
				THIS_LIB_TRAP(THIS_TrapVersion);
	
extern Err THIS_CompileInfo(UInt16 refNum, char *compileData, char *compileTime)
				THIS_LIB_TRAP(THIS_TrapCompileInfo);

extern Err THIS_AudioAdjVolumeSupported(UInt16 refNum, Int32 *boolean)
				THIS_LIB_TRAP(THIS_TrapAudioAdjVolumeSupported);

extern Err THIS_AudioDTMFSupported(UInt16 refNum, Int32 *boolean)
				THIS_LIB_TRAP(THIS_TrapAudioDTMFSupported);

extern Err THIS_AudioGetMasterVolume(UInt16 refNum, Int32 *volume)
				THIS_LIB_TRAP(THIS_TrapAudioGetMasterVolume);

extern Err THIS_AudioGetMute(UInt16 refNum, Int32 *boolean)
				THIS_LIB_TRAP(THIS_TrapAudioGetMute);

extern Err THIS_AudioPlayDTMFChar(UInt16 refNum, char *dtmfStr, Int32 toneLength)
				THIS_LIB_TRAP(THIS_TrapAudioPlayDTMFChar);

extern Err THIS_AudioPlayDTMFStr(UInt16 refNum, char *dtmfStr, Int32 toneLength, Int32 toneGap)
				THIS_LIB_TRAP(THIS_TrapAudioPlayDTMFStr);

extern Err THIS_AudioPlayWaveSupported(UInt16 refNum, Int32 *boolean)
				THIS_LIB_TRAP(THIS_TrapAudioPlayWaveSupported);

extern Err THIS_AudioRecordWaveSupported(UInt16 refNum, Int32 *boolean)
				THIS_LIB_TRAP(THIS_TrapAudioRecordWaveSupported);

extern Err THIS_AudioSetMasterVolume(UInt16 refNum, Int32 volume)
				THIS_LIB_TRAP(THIS_TrapAudioSetMasterVolume);

extern Err THIS_AudioSetMute(UInt16 refNum, Int32 boolean)
				THIS_LIB_TRAP(THIS_TrapAudioSetMute);

extern Err THIS_AudioVolumeDlg(UInt16 refNum, char *title)
				THIS_LIB_TRAP(THIS_TrapAudioVolumeDlg);
	
extern Err THIS_SilkGetGraffitiPersistence(UInt16 refNum, Int32 *ticks)
				THIS_LIB_TRAP(THIS_TrapSilkGetGraffitiPersistence);

extern Err THIS_SilkMaximizeWindow(UInt16 refNum)
				THIS_LIB_TRAP(THIS_TrapSilkMaximizeWindow);

extern Err THIS_SilkMinimizeWindow(UInt16 refNum)
				THIS_LIB_TRAP(THIS_TrapSilkMinimizeWindow);

extern Err THIS_SilkSetGraffitiPersistence(UInt16 refNum, Int32 ticks)
				THIS_LIB_TRAP(THIS_TrapSilkSetGraffitiPersistence);

extern Err THIS_SilkWindowMinimized(UInt16 refNum, Int32 *boolean)
				THIS_LIB_TRAP(THIS_TrapSilkWindowMinimized);

extern Err THIS_SizeForm(UInt16 refNum)
				THIS_LIB_TRAP(THIS_TrapSizeForm);

extern Err THIS_VgaBaseToVgaFont(UInt16 refNum, 
                             Int32 fontId, Int32 *vgaFontId)
				THIS_LIB_TRAP(THIS_TrapVgaBaseToVgaFont);

extern Err THIS_VgaFontSelect(UInt16 refNum, 
                             Int32 fontFormType, Int32 defaultFontId, Int32 *selectedFontId)
				THIS_LIB_TRAP(THIS_TrapVgaFontSelect);

extern Err THIS_VgaFrmModify(UInt16 refNum, 
                             Int32 *error)
				THIS_LIB_TRAP(THIS_TrapVgaFrmModify);

extern Err THIS_VgaFrmGetTitleHeight(UInt16 refNum, 
                                     Int32 *height)
				THIS_LIB_TRAP(THIS_TrapVgaFrmGetTitleHeight);

extern Err THIS_VgaGetScreenMode(UInt16 refNum, 
                                 Int32 *mode)
				THIS_LIB_TRAP(THIS_TrapVgaGetScreenMode);

extern Err THIS_VgaGetScreenOffset(UInt16 refNum, 
                                   Int32 *offset)
				THIS_LIB_TRAP(THIS_TrapVgaGetScreenOffset);

extern Err THIS_VgaGetScreenRotation(UInt16 refNum,
                                   Int32 *rotation)
  				THIS_LIB_TRAP(THIS_TrapVgaGetScreenRotation);

extern Err THIS_VgaGetScreenState(UInt16 refNum, 
                                  Int32 *mode)
				THIS_LIB_TRAP(THIS_TrapVgaGetScreenState);
				
extern Err THIS_VgaIsVgaFont(UInt16 refNum, 
                             Int32 fontId, Int32 *boolean)
				THIS_LIB_TRAP(THIS_TrapVgaIsVgaFont);

extern Err THIS_VgaRestoreScreenState(UInt16 refNum, 
                             Int32 *error)
				THIS_LIB_TRAP(THIS_TrapVgaRestoreScreenState);

extern Err THIS_VgaRotateSelect(UInt16 refNum, 
                                Int32 defaultRotation, Int32 *selectedRotation)
				THIS_LIB_TRAP(THIS_TrapVgaRotateSelect);

extern Err THIS_VgaSaveScreenState(UInt16 refNum)
				THIS_LIB_TRAP(THIS_TrapVgaSaveScreenState);

extern Err THIS_VgaSetScreenMode(UInt16 refNum, 
                                 Int32 mode, Int32 rotation, Int32 *error)
				THIS_LIB_TRAP(THIS_TrapVgaSetScreenMode);

extern Err THIS_VgaSetScreenState(UInt16 refNum, 
                      Int32 mode, Int32 rotation, Int32 offset, Int32 *error)
				THIS_LIB_TRAP(THIS_TrapVgaSetScreenState);

extern Err THIS_VgaVgaToBaseFont(UInt16 refNum, 
                             Int32 vgaFontId, Int32 *fontId)
				THIS_LIB_TRAP(THIS_TrapVgaVgaToBaseFont);

extern Err THIS_VgaWinDrawBitmapExpanded(UInt16 refNum, 
                             Int32 objectId, Int32 x, Int32 y)
				THIS_LIB_TRAP(THIS_TrapWinDrawBitmapExpanded);

/***************************************************
 *             Version 1.1 Functions:
 ***************************************************/
 

/*###################################################################
 #      S t a n d a r d ,  R E Q U I R E D    P r o t o t y p e s
 #
 #   You should not need to modify these prototypes.  Put your
 #   library's custom prototypes before these to separate your
 #   custom code from the standard, required code.  This way,
 #   the code you need to modify is easily found at the top of the
 #   file and you can "ignore" the standard, required, code at the
 #   end of the file.
 ###################################################################*/

extern Err THIS_LibOpen(UInt16 refNum)
				THIS_LIB_TRAP(sysLibTrapOpen);
				
extern Err THIS_LibClose(UInt16 refNum)
				THIS_LIB_TRAP(sysLibTrapClose);

extern Err THIS_LibSleep(UInt16 refNum)
				THIS_LIB_TRAP(sysLibTrapSleep);

extern Err THIS_LibWake(UInt16 refNum)
				THIS_LIB_TRAP(sysLibTrapWake);

// For loading the library in Palm OS Mac emulation mode
extern Err THIS_LibInstall(UInt16 refNum, SysLibTblEntryPtr entryP);

/*###################################################################*/

#ifdef __cplusplus 
}
#endif

#endif	// __THIS_LIB_H__

