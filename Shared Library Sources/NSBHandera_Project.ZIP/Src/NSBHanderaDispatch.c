#ifndef PILOT_PRECOMPILED_HEADERS_OFF
#define	PILOT_PRECOMPILED_HEADERS_OFF
#endif


#if __PALMOS_TRAPS__
	#define EMULATION_LEVEL	EMULATION_NONE
#endif

#undef __PALMOS_TRAPS__
#define __PALMOS_TRAPS__ 	0
#define	USE_TRAPS 	0


// Include Pilot headers
#include <PalmOS.h>


// Our library public definitions (library API)
#include "NSBHandera.h"


#if EMULATION_LEVEL == EMULATION_NONE
	#define THIS_LibInstall		__Startup__
#endif


// Local prototypes

Err THIS_LibInstall(UInt16 refNum, SysLibTblEntryPtr entryP);
static MemPtr	asm THIS_LibDispatchTable(void);



/************************************************************
 *               T H I S _ L i b I n s t a l l
 ***********************************************************/
Err THIS_LibInstall(UInt16 refNum, SysLibTblEntryPtr entryP) {
	entryP->dispatchTblP = (MemPtr*)THIS_LibDispatchTable();
	entryP->globalsP = 0;
	return 0;
}


/************************************************************
 *          T H I S _ L i b D i s p a t c h T a b l e
 *
 *  WARNING!!! 	This table must match the ordering of the
 *      		library's trap numbers!
 ***********************************************************/

// First, define the size of the jump instruction
#if EMULATION_LEVEL == EMULATION_NONE
	#define prvJmpSize		4	// Palm OS uses short jumps
#elif EMULATION_LEVEL == EMULATION_MAC
	#define prvJmpSize		6	// Our Mac builds use long jumps
#else
	#error unsupported emulation mode
#endif	// EMULATION_LEVEL...

// Now, define a macro for offset list entries
#define	kOffset		(2 * ((THIS_TrapLast - sysLibTrapCustom) + 5))
#define libDispatchEntry(index)		(kOffset+((index)*prvJmpSize))


static MemPtr	asm THIS_LibDispatchTable(void) {
	LEA		@Table, A0			// table ptr
	RTS							// exit with it

@Table:
	// Offset to library name
	DC.W		@Name
	
	//
	// Library function dispatch entries:
	//
	// ***IMPORTANT***
	// The index parameters passed to the macro libDispatchEntry
	// must be numbered consecutively, beginning with zero.
	//
	
	// Standard traps
	DC.W		libDispatchEntry(0)		// LibOpen
	DC.W		libDispatchEntry(1)		// LibClose
	DC.W		libDispatchEntry(2)		// LibSleep
	DC.W		libDispatchEntry(3)		// LibWake
	
	// Start of the Custom traps
	/*************************************************
	 *  V e r s i o n    1 . 0    F u n c t i o n s
	 *************************************************/
	DC.W		libDispatchEntry(4)
	DC.W		libDispatchEntry(5)
	DC.W		libDispatchEntry(6)
	DC.W		libDispatchEntry(7)
	DC.W		libDispatchEntry(8)
	DC.W		libDispatchEntry(9)
	DC.W		libDispatchEntry(10)
	DC.W		libDispatchEntry(11)
	DC.W		libDispatchEntry(12)
	DC.W		libDispatchEntry(13)
	DC.W		libDispatchEntry(14)
	DC.W		libDispatchEntry(15)
	DC.W		libDispatchEntry(16)
	DC.W		libDispatchEntry(17)
	DC.W		libDispatchEntry(18)
	DC.W		libDispatchEntry(19)
	DC.W		libDispatchEntry(20)
	DC.W		libDispatchEntry(21)
	DC.W		libDispatchEntry(22)
	DC.W		libDispatchEntry(23)
	DC.W		libDispatchEntry(24)
	DC.W		libDispatchEntry(25)
	DC.W		libDispatchEntry(26)
	DC.W		libDispatchEntry(27)
	DC.W		libDispatchEntry(28)
	DC.W		libDispatchEntry(29)
	DC.W		libDispatchEntry(30)
	DC.W		libDispatchEntry(31)
	DC.W		libDispatchEntry(32)
	DC.W		libDispatchEntry(33)
	DC.W		libDispatchEntry(34)
	DC.W		libDispatchEntry(35)
	DC.W		libDispatchEntry(36)
	DC.W		libDispatchEntry(37)
	DC.W		libDispatchEntry(38)
	/*************************************************
	 *  V e r s i o n    1 . 1    F u n c t i o n s
	 *************************************************/
	
// Standard library function handlers
@GotoS1:	JMP 		THIS_LibOpen
@GotoS2:	JMP 		THIS_LibClose
@GotoS3:	JMP 		THIS_LibSleep
@GotoS4:	JMP 		THIS_LibWake
	
// Custom library function handlers
/*********************************************************
 *      V e r s i o n    1 . 0    F u n c t i o n s
 *********************************************************/
@Goto1:		JMP 		THIS_Version
@Goto2:		JMP 		THIS_CompileInfo
@Goto3:		JMP 		THIS_AudioAdjVolumeSupported
@Goto4:		JMP 		THIS_AudioDTMFSupported
@Goto5:		JMP 		THIS_AudioGetMasterVolume
@Goto6:		JMP 		THIS_AudioGetMute
@Goto7:		JMP 		THIS_AudioPlayDTMFChar
@Goto8:		JMP 		THIS_AudioPlayDTMFStr
@Goto9:		JMP 		THIS_AudioPlayWaveSupported
@Goto10:	JMP 		THIS_AudioRecordWaveSupported
@Goto11:	JMP 		THIS_AudioSetMasterVolume
@Goto12:	JMP 		THIS_AudioSetMute
@Goto13:	JMP 		THIS_AudioVolumeDlg
@Goto14:	JMP			THIS_SilkGetGraffitiPersistence
@Goto15:	JMP			THIS_SilkMaximizeWindow
@Goto16:	JMP			THIS_SilkMinimizeWindow
@Goto17:	JMP			THIS_SilkSetGraffitiPersistence
@Goto18:	JMP			THIS_SilkWindowMinimized
@Goto19:	JMP			THIS_SizeForm
@Goto20:	JMP			THIS_VgaBaseToVgaFont
@Goto21:	JMP			THIS_VgaFontSelect
@Goto22:	JMP			THIS_VgaFrmModify
@Goto23:	JMP 		THIS_VgaFrmGetTitleHeight
@Goto24:	JMP 		THIS_VgaGetScreenMode
@Goto25:	JMP 		THIS_VgaGetScreenOffset
@Goto26:	JMP 		THIS_VgaGetScreenRotation
@Goto27:	JMP 		THIS_VgaGetScreenState
@Goto28:	JMP 		THIS_VgaIsVgaFont
@Goto29:	JMP 		THIS_VgaRestoreScreenState
@Goto30:	JMP 		THIS_VgaRotateSelect
@Goto31:	JMP			THIS_VgaSaveScreenState
@Goto32:	JMP			THIS_VgaSetScreenMode
@Goto33:	JMP			THIS_VgaSetScreenState
@Goto34:	JMP			THIS_VgaVgaToBaseFont
@Goto35:	JMP			THIS_VgaWinDrawBitmapExpanded
/*********************************************************
 *      V e r s i o n    1 . 1    F u n c t i o n s
 *********************************************************/

// This name identifies the library.  Apps can pass it to 
// SysLibFind() to check if the library is already installed.
@Name:		DC.B		THIS_LibName

}

