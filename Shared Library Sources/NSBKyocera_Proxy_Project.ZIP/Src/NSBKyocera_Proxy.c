//
//             N S B K y o c e r a _ P r o x y
//
//

#include <PalmOS.h>
#include <SysEvtMgr.h>
#include "NSBKyocera_Proxy.h"
#include "pdqCore.h"

#define appVersionNum           0x00
#define appPrefID               0x00
#define appPrefVersionNum       0x00
#define appFileCreator          'nsbK'


typedef struct {
	UInt32                   eventTime;
	Boolean                  started;
	UInt32                   signalClass;
	UInt32                   signal;
	CallInfoType             callInfo;
	AirTimeType              airTime;
	char                     szArg[MAX_DIGITS + 1];
	UInt32		             dwArg;
	Boolean                  bArg;
	Int16		             nArg;
	MsgSigType               msgInfo;
	char                     szMessage[250];
}  EventData;

typedef struct {
    LocalID runningApp;
    Boolean exclusive;
    Int16   waitTime;
    LocalID startApp[3][12];
    SigPriorityType priority[3][12];
} RegisteredApps;

//
//                  D o A l e r t
//
static int DoAlert(Char *msg)  {
    return FrmCustomAlert(Proxy_Alert, msg, "", "");
}

//
//         R e r e g i s t e r S i g n a l s
//
void ReregisterSignals(void) {
    RegisteredApps  rA;
    UInt16          rASize;
    UInt32          uClass;
    UInt32          uMask;
    UInt16          coreRefNum;
    Err				error;
    UInt32          sigValues[3][12] = 
        {{SGN_TAPI_IDLE,SGN_TAPI_INCOMING,SGN_TAPI_LOST,SGN_TAPI_MISSED,SGN_TAPI_FAILED,SGN_TAPI_CALLING,SGN_TAPI_CONVERSATION,SGN_TAPI_ENDED,SGN_TAPI_DIALPAUSED,SGN_TAPI_CALLERID,SGN_TAPI_DIALEDDTMF,SGN_TAPI_INCOMINGMODE},
         {SGN_POWER,SGN_CHARGING,SGN_SERVICE,SGN_ROAM,SGN_VOICEPRIVACY,SGN_NAMCHANGED,SGN_RSSI,SGN_DIGITAL,SGN_LOCK,SGN_MODULEFAILURE,SGN_AIRTIMECHANGED,SGN_MUTED},
         {SGN_MSG_RAW_SMS,SGN_MSG_CARRIER_VOICE_MAIL,SGN_MSG_TEXT_MESSAGE,SGN_MSG_PAGE,0,0,0,0,0,0,0,0}};
	UInt16			i, n;

   	rASize = sizeof(rA);
	if (PrefGetAppPreferences(appFileCreator, 1, 
                             &rA, &rASize, true) != noPreferenceFound) {
       	error = SysLibFind(PDQCoreLibName, &coreRefNum);
       	if (!error) {
	        for (i = 0; i < 3; i++) {
    	        switch (i) {
        	        case 0:
            	        uClass = SGN_CLASS_TAPI;
	            	    break;
			        case 1:
   						uClass = SGN_CLASS_MSG;
			            break;
		    	    case 2:
   						uClass = SGN_CLASS_MODULE;
   						break;
				}
    	        for (n = 0; n < 12; n++) {
        	        if (rA.startApp[i][n] != 0) {
            	        uMask = sigValues[i][n];
						error = PDQSigRegister(coreRefNum, uClass, uMask,
                    	                       rA.priority[i][n],
                        	                   appFileCreator, sysFileTApplication);
	                }
    	        }
    	    }
        }
    }     
}

//
//            P r o c e s s S i g n a l s
//
void ProcessSignals(MemPtr cmdPBP) {
    Err             error = 0;
    CallInfoPtr     ciPtr;
    AirTimePtr      atPtr;
    SignalParamsPtr spPtr;
    MsgSigPtr       msgPtr;
    EventData       eD;
    RegisteredApps  rA;
    UInt16          eDSize;
    UInt16          rASize;
    LocalID         runApp;
    UInt32          sigValues[3][12] = 
        {{SGN_TAPI_IDLE,SGN_TAPI_INCOMING,SGN_TAPI_LOST,SGN_TAPI_MISSED,SGN_TAPI_FAILED,SGN_TAPI_CALLING,SGN_TAPI_CONVERSATION,SGN_TAPI_ENDED,SGN_TAPI_DIALPAUSED,SGN_TAPI_CALLERID,SGN_TAPI_DIALEDDTMF,SGN_TAPI_INCOMINGMODE},
         {SGN_POWER,SGN_CHARGING,SGN_SERVICE,SGN_ROAM,SGN_VOICEPRIVACY,SGN_NAMCHANGED,SGN_RSSI,SGN_DIGITAL,SGN_LOCK,SGN_MODULEFAILURE,SGN_AIRTIMECHANGED,SGN_MUTED},
         {SGN_MSG_RAW_SMS,SGN_MSG_CARRIER_VOICE_MAIL,SGN_MSG_TEXT_MESSAGE,SGN_MSG_PAGE,0,0,0,0,0,0,0,0}};
    UInt16          i, n;
    
    LocalID         localId;
    UInt16          cardNo;
    UInt32          curTime;
    EventType       event;

   	eDSize = sizeof(eD);
	PrefGetAppPreferences(appFileCreator, 0, 
                          &eD, &eDSize, true);
   	rASize = sizeof(rA);
	if (PrefGetAppPreferences(appFileCreator, 1, 
                              &rA, &rASize, true) == noPreferenceFound) {
        for (i = 0; i < 3; i++)
            for (n = 0; n < 12; n++) {
                rA.startApp[i][n] = 0;
                rA.priority[i][n] = 0;
            }
    }
    spPtr = (SignalParamsPtr) cmdPBP;
    eD.eventTime = TimGetSeconds();
    eD.signalClass = spPtr->signalClass;
    eD.signal = spPtr->signal;
    switch (spPtr->signalClass) {
        case SGN_CLASS_TAPI:
            i = 0;
            if ((spPtr->signal & SGN_TAPI_INCOMING) ||
                (spPtr->signal & SGN_TAPI_LOST) ||
                (spPtr->signal & SGN_TAPI_MISSED) ||
                (spPtr->signal & SGN_TAPI_FAILED) ||
                (spPtr->signal & SGN_TAPI_CALLING) ||
                (spPtr->signal & SGN_TAPI_CONVERSATION) ||
                (spPtr->signal & SGN_TAPI_ENDED) ||
                (spPtr->signal & SGN_TAPI_CALLERID)) {                        
                ciPtr = (CallInfoPtr) spPtr->params.pVoidArg;
	            eD.callInfo.dwSignalHist = ciPtr->dwSignalHist;
	            eD.callInfo.callFlags = ciPtr->callFlags;
	            eD.callInfo.nCallerIDStatus = ciPtr->nCallerIDStatus;
	            eD.callInfo.bDialingPaused = ciPtr->bDialingPaused;
	            StrCopy(eD.callInfo.szNumber, ciPtr->szNumber);
	            eD.callInfo.lTimeOfCall = ciPtr->lTimeOfCall;
	            eD.callInfo.lCallDuration = ciPtr->lCallDuration;
	            StrCopy(eD.callInfo.szWaiting, ciPtr->szWaiting);
	            StrCopy(eD.callInfo.szExt, ciPtr->szExt);
	            eD.callInfo.nErr = ciPtr->nErr;
	            eD.callInfo.dataCallInfo.callType = ciPtr->dataCallInfo.callType;
	            eD.callInfo.dataCallInfo.dwBaudRate = ciPtr->dataCallInfo.dwBaudRate;
            }
            if (spPtr->signal & SGN_TAPI_DIALPAUSED)
                eD.nArg = spPtr->params.nArg;
            if (spPtr->signal & SGN_TAPI_DIALEDDTMF)
                StrCopy(eD.szArg, spPtr->params.szArg);
            break;
        case SGN_CLASS_MSG:
            i = 1;
            if ((spPtr->signal & SGN_POWER) ||
                (spPtr->signal & SGN_CHARGING) ||
                (spPtr->signal & SGN_ROAM) ||
                (spPtr->signal & SGN_NAMCHANGED) ||
                (spPtr->signal & SGN_LOCK))
                eD.nArg = spPtr->params.nArg;
			if ((spPtr->signal & SGN_SERVICE) ||
			    (spPtr->signal & SGN_VOICEPRIVACY) ||
				(spPtr->signal & SGN_DIGITAL) ||
			    (spPtr->signal & SGN_MUTED))
			    eD.bArg = spPtr->params.bArg;
			if (spPtr->signal & SGN_RSSI)
				eD.dwArg = spPtr->params.dwArg;
			if (spPtr->signal & SGN_AIRTIMECHANGED) {
	            atPtr = (AirTimePtr) spPtr->params.pVoidArg;
				eD.airTime.dwLocalSecs = atPtr->dwLocalSecs;
				eD.airTime.dwGMTSecs = atPtr->dwGMTSecs;
				eD.airTime.dwAdjust = atPtr->dwAdjust;
			}
            break;
        case SGN_CLASS_MODULE:
            i = 2;
            if ((spPtr->signal & SGN_MSG_CARRIER_VOICE_MAIL) ||
                (spPtr->signal & SGN_MSG_TEXT_MESSAGE) ||
                (spPtr->signal & SGN_MSG_PAGE)) {
                msgPtr = (MsgSigPtr) spPtr->params.pVoidArg;
                eD.msgInfo.nNumUnreadVoice = msgPtr->nNumUnreadVoice;
                eD.msgInfo.nNumUnreadText = msgPtr->nNumUnreadText;
                eD.msgInfo.status = msgPtr->status;
                eD.msgInfo.ulTime = msgPtr->ulTime;
                StrCopy(eD.msgInfo.szCallBack, msgPtr->szCallBack);
                StrNCopy(eD.szMessage, msgPtr->szMessage, sizeof(eD.szMessage) - 1);
                eD.szMessage[sizeof(eD.szMessage) - 1] = 0;
            }
            break;
    }
    runApp = 0;
    for (n = 0; n < 12; n++)
        if (spPtr->signal & sigValues[i][n])
            if (rA.startApp[i][n] != 0) {
                runApp = rA.startApp[i][n];
                break;
          	}
    eD.started = false;
    if (runApp != 0 && runApp != rA.runningApp)
        eD.started = true;
    PrefSetAppPreferences(appFileCreator, 0, 0, 
                          &eD, sizeof(eD), true);
    if (runApp != 0) {
        if (runApp == rA.runningApp) {
           	event.eType = 25678;
            event.screenX = 25678;
            event.screenY = 25678;
            EvtAddEventToQueue (&event);
        }
        else
          	if (runApp != rA.runningApp) {
          	    rA.runningApp = runApp;
			    PrefSetAppPreferences(appFileCreator, 1, 0, 
            			              &rA, sizeof(rA), true);
                SysCurAppDatabase(&cardNo, &localId);
                curTime = TimGetSeconds();
                if (rA.waitTime < 0)
                    rA.waitTime = 2;
   	            curTime = curTime + rA.waitTime;
       	        AlmSetAlarm (cardNo, localId, runApp, curTime, 0);
           	    // Switch to the Application Launcher
               	event.eType = keyDownEvent;
                event.data.keyDown.chr = launchChr;
                event.data.keyDown.modifiers = commandKeyMask;
   	            EvtAddEventToQueue (&event);
   	            eD.started = true;
           	}
    }
}

//
//                 P i l o t M a i n
//
UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
    LocalID         runApp;
    
    switch (cmd) {
        case sysAppLaunchCmdNormalLaunch:
            DoAlert("This program does not have a User Interface.");
        	break;
        case sysAppLaunchCmdSystemReset:
        	ReregisterSignals();
            break;
        case sysAppLaunchCmd_PDQSignal:
        	ProcessSignals(cmdPBP);
            break;
        case sysAppLaunchCmdDisplayAlarm:	
            runApp = 0;
            if (cmdPBP != NULL)
   				runApp = (LocalID) *((int *) cmdPBP);
   		    if (runApp != 0)
                SysUIAppSwitch(0, runApp, 
                               sysAppLaunchCmdNormalLaunch, NULL);
            break;
    }

    return 0;
}

