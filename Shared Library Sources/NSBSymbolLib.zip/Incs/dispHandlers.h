@GotoNSB_SSMLibOpen:
	JMP 		NSB_SSMLibOpen
@GotoNSB_SSMLibClose:
	JMP 		NSB_SSMLibClose
@GotoNSB_SSMLibSleep:
	JMP 		NSB_SSMLibSleep
@GotoNSB_SSMLibWake:
	JMP 		NSB_SSMLibWake
@GotoNSB_SSMLibIsPalmSymbolUnit:
	JMP 		NSB_SSMLibIsPalmSymbolUnit
@GotoNSB_SSMLibCmdScanEnable:
	JMP 		NSB_SSMLibCmdScanEnable
@GotoNSB_SSMLibCmdScanDisable:
	JMP 		NSB_SSMLibCmdScanDisable
@GotoNSB_SSMLibCmdScanSetTriggeringModes:
	JMP 		NSB_SSMLibCmdScanSetTriggeringModes
@GotoNSB_SSMLibCmdScanSetBarcodeEnabled:
	JMP 		NSB_SSMLibCmdScanSetBarcodeEnabled
@GotoNSB_SSMLibCmdSendParams:
	JMP 		NSB_SSMLibCmdSendParams
@GotoNSB_SSMLibCmdStartDecode:
	JMP 		NSB_SSMLibCmdStartDecode
@GotoNSB_SSMLibCmdStopDecode:
	JMP 		NSB_SSMLibCmdStopDecode
@GotoNSB_SSMLibGetDecodedData:
	JMP 		NSB_SSMLibGetDecodedData
@GotoNSB_SSMLibGetLastScanData:
	JMP 		NSB_SSMLibGetLastScanData
@GotoNSB_SSMLibGetBarType:
	JMP 		NSB_SSMLibGetBarType
@GotoNSB_SSMLibCmdScanLedOn:
	JMP 		NSB_SSMLibCmdScanLedOn
@GotoNSB_SSMLibCmdScanLedOff:
	JMP 		NSB_SSMLibCmdScanLedOff
