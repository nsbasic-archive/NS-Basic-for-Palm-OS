#define	kOffset		(2*18)						// NOTE: This is empirical!!!!!!
