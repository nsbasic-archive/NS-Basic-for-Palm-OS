//
//    N S B A l a r m P r o x y 5    C o n s t a n t s
//
//    These constants must also match the
//    Target Launcher settings for linking.
//
// Constants
//
#include "NSBAlarmProxy5.h"
#define appFileCreator          'NSB6'
