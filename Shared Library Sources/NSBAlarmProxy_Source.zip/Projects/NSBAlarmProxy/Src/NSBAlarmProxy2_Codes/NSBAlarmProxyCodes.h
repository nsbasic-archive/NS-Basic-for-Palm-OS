//
//    N S B A l a r m P r o x y 2    C o n s t a n t s
//
//    These constants must also match the
//    Target Launcher settings for linking.
//
// Constants
//
#include "NSBAlarmProxy2.h"
#define appFileCreator          'NSB3'
