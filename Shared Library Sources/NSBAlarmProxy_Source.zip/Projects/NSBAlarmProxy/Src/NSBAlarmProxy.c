//
//                 N S B A l a r m P r o x y
//
//  Version: 1.0
//  Date:    September, 2001
//  Author:  Ron Glowka, Austin, Texas, U.S.A.
//

#include <PalmOS.h>
#include <SysEvtMgr.h>
#include "NSBAlarmProxyCodes.h"

#define alarmVersionNum           0x00
#define alarmSetPrefID            0x00
#define alarmLogPrefID            0x01

typedef struct {
    UInt32 alarmTime;
    UInt32 resetTime;
    Int32  resetCount;
    Int32  resetLimit;
    Int32  cmd;
    Char   msg[81];
} AlarmLog;

//
//                  D o A l e r t
//
static int DoAlert(Char *msg)  {
    return FrmCustomAlert(AlarmAlert, msg, "", "");
}

//
//                 P i l o t M a i n
//
UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
    Err        error = 0;
    LocalID    localId;
    UInt16     cardNo;
    Int32      cmdPBPVal = -1;
    Int32      okCancel = 0;
    UInt32     curTime;
    Int32      waitTime = 2;
    AlarmLog   alarmLog;
    AlarmLog   alarmPref;
    UInt16     logSize;
    Char       *s;
    EventType  event;
    Char       eventKey;

    if (cmdPBP != NULL)
        cmdPBPVal = *((int *) cmdPBP);
	
    switch (cmd) {
        case sysAppLaunchCmdNormalLaunch:
        case sysAppLaunchCmdSystemReset:
            break;
        case sysAppLaunchCmdAlarmTriggered:
            if (cmdPBPVal == 1 || cmdPBPVal == 2)
                SndPlaySystemSound(sndAlarm);
            break;
        case sysAppLaunchCmdDisplayAlarm:	

            if (cmdPBPVal < -30000) {
                event.eType = (0 - cmdPBPVal);
                EvtAddEventToQueue (&event);
                SysCurAppDatabase(&cardNo, &localId);
                curTime = TimGetSeconds();
                curTime = curTime + ((0 - cmdPBPVal) - 30000);
                AlmSetAlarm (cardNo, localId, cmdPBPVal, curTime, 0);
                return 0;
            }

            curTime = TimGetSeconds();
            logSize = sizeof(alarmPref);
            if (PrefGetAppPreferences(appFileCreator, alarmSetPrefID, 
                              &alarmPref, &logSize, false) != 0) {
                logSize = 0;
                alarmPref.msg[0] = 0;
                alarmPref.resetTime = 0;
                alarmPref.resetCount = 0;
            }
            if (cmdPBPVal == 2)
                okCancel = DoAlert(alarmPref.msg);
            if (cmdPBPVal != -99 && okCancel == 0 && logSize > 0) {
                if (alarmPref.resetTime != 0) {
                    logSize = sizeof(alarmLog);
                    if (PrefGetAppPreferences(appFileCreator, alarmLogPrefID, 
                              &alarmLog, &logSize, false) != 0) 
                        alarmLog.resetCount = 0;
                    alarmLog.resetCount++;
                }
                else
                    alarmLog.resetCount = 0;
                alarmLog.alarmTime = curTime;
                alarmLog.resetTime = alarmPref.resetTime;
                alarmLog.resetLimit = alarmPref.resetLimit;
                alarmLog.cmd = cmdPBPVal;
                StrCopy(alarmLog.msg, alarmPref.msg);
                logSize = sizeof(alarmLog);
                PrefSetAppPreferences(appFileCreator, alarmLogPrefID, alarmVersionNum, 
                                      &alarmLog, sizeof(alarmLog), 0);
            }
            if (cmdPBPVal == 3) {
                if ((s = StrChr(alarmPref.msg, ';')) != NULL)
                    *s = '\0';
                if ((s = StrChr(alarmPref.msg, ',')) != NULL) {
                    *s = '\0';
                    s++;
                    waitTime = StrAToI(s);
                    if (waitTime <= 0)
                        waitTime = 2;
                }
                if (StrLen(alarmPref.msg) > 0) {
                    SysCurAppDatabase(&cardNo, &localId);
                    curTime = TimGetSeconds();
                    curTime = curTime + waitTime;
                    AlmSetAlarm (cardNo, localId, -99, curTime, 0);
                    // Switch to the Application Launcher
                    event.eType = keyDownEvent;
                    event.data.keyDown.chr = launchChr;
                    event.data.keyDown.modifiers = commandKeyMask;
                    EvtAddEventToQueue (&event);
                }
            }
            if (cmdPBPVal == 0) {
                event.eType = nilEvent;
                EvtAddEventToQueue (&event);
            }
            if (cmdPBPVal > 3 && cmdPBPVal < 256) {
                eventKey = (Char) cmdPBPVal;
                EvtEnqueueKey (eventKey, 0, 0);
            }
            if (cmdPBPVal >= 24832) {
                event.eType = cmdPBPVal;
                EvtAddEventToQueue (&event);
            }
            if (cmdPBPVal != 3 && logSize > 0) {
                if ((alarmPref.resetTime > 0) &&
                    ((alarmLog.resetCount < alarmPref.resetLimit) || 
                     (alarmPref.resetLimit < 0))) {
                    SysCurAppDatabase(&cardNo, &localId);
                    curTime = curTime + alarmPref.resetTime;
                    AlmSetAlarm (cardNo, localId, alarmPref.cmd, curTime, 0);
                }
            }
            if (cmdPBPVal == -99) {
                if ((s = StrChr(alarmPref.msg, ';')) != NULL)
                    *s = '\0';
                if ((s = StrChr(alarmPref.msg, ',')) != NULL)
                    *s = '\0';
                if (StrLen(alarmPref.msg) > 0) {
                    localId = DmFindDatabase (0, alarmPref.msg) ;
                    if (localId != 0) {
                        SysUIAppSwitch (0, localId, 
                                        sysAppLaunchCmdNormalLaunch, NULL);
                    }
                }
            }
            break;
    }

    return 0;
}

