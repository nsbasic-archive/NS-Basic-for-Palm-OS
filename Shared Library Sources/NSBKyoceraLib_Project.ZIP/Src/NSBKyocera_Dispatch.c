#ifndef PILOT_PRECOMPILED_HEADERS_OFF
#define	PILOT_PRECOMPILED_HEADERS_OFF
#endif


#if __PALMOS_TRAPS__
	#define EMULATION_LEVEL	EMULATION_NONE
#endif

#undef __PALMOS_TRAPS__
#define __PALMOS_TRAPS__ 	0
#define	USE_TRAPS 	0


// Include Pilot headers
#include <PalmOS.h>


// Our library public definitions (library API)
#include "NSBKyocera.h"


#if EMULATION_LEVEL == EMULATION_NONE
	#define THIS_LibInstall		__Startup__
#endif


// Local prototypes

Err THIS_LibInstall(UInt16 refNum, SysLibTblEntryPtr entryP);
static MemPtr	asm THIS_LibDispatchTable(void);



/************************************************************
 *               T H I S _ L i b I n s t a l l
 ***********************************************************/
Err THIS_LibInstall(UInt16 refNum, SysLibTblEntryPtr entryP) {
	entryP->dispatchTblP = (MemPtr*)THIS_LibDispatchTable();
	entryP->globalsP = 0;
	return 0;
}


/************************************************************
 *          T H I S _ L i b D i s p a t c h T a b l e
 *
 *  WARNING!!! 	This table must match the ordering of the
 *      		library's trap numbers!
 ***********************************************************/

// First, define the size of the jump instruction
#if EMULATION_LEVEL == EMULATION_NONE
	#define prvJmpSize		4	// Palm OS uses short jumps
#elif EMULATION_LEVEL == EMULATION_MAC
	#define prvJmpSize		6	// Our Mac builds use long jumps
#else
	#error unsupported emulation mode
#endif	// EMULATION_LEVEL...

// Now, define a macro for offset list entries
#define	kOffset		(2 * ((TrapLast - sysLibTrapCustom) + 5))
#define libDispatchEntry(index)		(kOffset+((index)*prvJmpSize))


static MemPtr	asm THIS_LibDispatchTable(void) {
	LEA		@Table, A0			// table ptr
	RTS							// exit with it

@Table:
	// Offset to library name
	DC.W		@Name
	
	//
	// Library function dispatch entries:
	//
	// ***IMPORTANT***
	// The index parameters passed to the macro libDispatchEntry
	// must be numbered consecutively, beginning with zero.
	//
	
	// Standard traps
	DC.W		libDispatchEntry(0)		// LibOpen
	DC.W		libDispatchEntry(1)		// LibClose
	DC.W		libDispatchEntry(2)		// LibSleep
	DC.W		libDispatchEntry(3)		// LibWake
	
	// Start of the Custom traps
	DC.W		libDispatchEntry(4)
	DC.W		libDispatchEntry(5)
	DC.W		libDispatchEntry(6)
	DC.W		libDispatchEntry(7)
	DC.W		libDispatchEntry(8)
	DC.W		libDispatchEntry(9)
	DC.W		libDispatchEntry(10)
	DC.W		libDispatchEntry(11)
	DC.W		libDispatchEntry(12)
	DC.W		libDispatchEntry(13)
	DC.W		libDispatchEntry(14)
	DC.W		libDispatchEntry(15)
	DC.W		libDispatchEntry(16)
	DC.W		libDispatchEntry(17)
	DC.W		libDispatchEntry(18)
	DC.W		libDispatchEntry(19)
	DC.W		libDispatchEntry(20)
	DC.W		libDispatchEntry(21)
	DC.W		libDispatchEntry(22)
	DC.W		libDispatchEntry(23)
	DC.W		libDispatchEntry(24)
	DC.W		libDispatchEntry(25)
	DC.W		libDispatchEntry(26)
	DC.W		libDispatchEntry(27)
	DC.W		libDispatchEntry(28)
	DC.W		libDispatchEntry(29)
	DC.W		libDispatchEntry(30)
	DC.W		libDispatchEntry(31)
	DC.W		libDispatchEntry(32)
	DC.W		libDispatchEntry(33)
	DC.W		libDispatchEntry(34)
	DC.W		libDispatchEntry(35)
	DC.W		libDispatchEntry(36)
	DC.W		libDispatchEntry(37)
	DC.W		libDispatchEntry(38)
	DC.W		libDispatchEntry(39)
	DC.W		libDispatchEntry(40)
	DC.W		libDispatchEntry(41)
	DC.W		libDispatchEntry(42)
	DC.W		libDispatchEntry(43)
	DC.W		libDispatchEntry(44)
	DC.W		libDispatchEntry(45)
	DC.W		libDispatchEntry(46)
	DC.W		libDispatchEntry(47)
	DC.W		libDispatchEntry(48)
	DC.W		libDispatchEntry(49)
	DC.W		libDispatchEntry(50)
	DC.W		libDispatchEntry(51)
	DC.W		libDispatchEntry(52)
	DC.W		libDispatchEntry(53)
	DC.W		libDispatchEntry(54)
	DC.W		libDispatchEntry(55)
	DC.W		libDispatchEntry(56)
	DC.W		libDispatchEntry(57)
	DC.W		libDispatchEntry(58)
	DC.W		libDispatchEntry(59)
	DC.W		libDispatchEntry(60)
	DC.W		libDispatchEntry(61)
	DC.W		libDispatchEntry(62)
	DC.W		libDispatchEntry(63)
	DC.W		libDispatchEntry(64)
	DC.W		libDispatchEntry(65)
	DC.W		libDispatchEntry(66)
	DC.W		libDispatchEntry(67)
	DC.W		libDispatchEntry(68)
	DC.W		libDispatchEntry(69)
	DC.W		libDispatchEntry(70)
	DC.W		libDispatchEntry(71)
	DC.W		libDispatchEntry(72)
	DC.W		libDispatchEntry(73)
	DC.W		libDispatchEntry(74)
	DC.W		libDispatchEntry(75)
	DC.W		libDispatchEntry(76)
	DC.W		libDispatchEntry(77)
	DC.W		libDispatchEntry(78)

// Standard library function handlers
@Goto0:		JMP 		THIS_LibOpen
@Goto1:		JMP 		THIS_LibClose
@Goto2:		JMP 		THIS_LibSleep
@Goto3:		JMP 		THIS_LibWake
	
// Custom library function handlers
@Goto4:		JMP 		Version
@Goto5:		JMP 		CompileInfo
@Goto6:		JMP 		CoreLibPresent
@Goto7:		JMP			RegistryLibPresent
@Goto8:		JMP			CoreLibGetVersion
@Goto9:		JMP			SigRegister
@Goto10:	JMP			SigUnregister
@Goto11:	JMP			SigEnumerate
@Goto12:	JMP			SigMask
@Goto13:	JMP			SigPriority
@Goto14:	JMP			SigCreator
@Goto15:	JMP			SigType
@Goto16:	JMP			ModPower
@Goto17:	JMP			ModSetEarVolume
@Goto18:	JMP			ModGetState
@Goto19:	JMP			ModStatePowered
@Goto20:	JMP			ModStateInCall
@Goto21:	JMP			ModStateAMPS
@Goto22:	JMP			ModStateNoService
@Goto23:	JMP			ModStateHardPaused
@Goto24:	JMP			ModStateMuted
@Goto25:	JMP			ModStateLPM
@Goto26:	JMP			ModMute
@Goto27:	JMP			ModGetPhoneNumber
@Goto28:	JMP			TelMakeCall
@Goto29:	JMP			TelEndCall
@Goto30:	JMP			TelAnswerCall
@Goto31:	JMP			TelGenerateDTMF
@Goto32:	JMP			TelGetCallInfo
@Goto33:	JMP			TelCISignalHist
@Goto34:	JMP			TelCICallFlags
@Goto35:	JMP			TelCICallerIDStatus
@Goto36:	JMP			TelCIDialingPaused
@Goto37:	JMP			TelCINumber
@Goto38:	JMP			TelCITimeOfCall
@Goto39:	JMP			TelCICallDuration
@Goto40:	JMP			TelCIWaiting
@Goto41:	JMP			TelCIExt
@Goto42:	JMP			TelCIErr
@Goto43:	JMP			TelCICallType
@Goto44:	JMP			TelCIBaudRate
@Goto45:	JMP			TelResumeDialing
@Goto46:	JMP			TelCancelPause
@Goto47:	JMP			TelFormatNumber
@Goto48:	JMP			TelGetDigit
@Goto49:	JMP			RegGetVersion
@Goto50:	JMP			RegAddScheme
@Goto51:	JMP			RegRemoveScheme
@Goto52:	JMP			RegEnableScheme
@Goto53:	JMP			RegEnumSchemes
@Goto54:	JMP			RegSchemeName
@Goto55:	JMP			RegSchemeShortName
@Goto56:	JMP			RegSchemeCreator
@Goto57:	JMP			RegSchemeFlags
@Goto58:	JMP			RegSchemeEnabled
@Goto59:	JMP			RegGetHandler
@Goto60:	JMP			RegProcessURL
@Goto61:	JMP			RegProcessMailAddress
@Goto62:	JMP			RegAddMacro
@Goto63:	JMP			RegRemoveMacro
@Goto64:	JMP			RegEnumMacros
@Goto65:	JMP			RegMacroDesc
@Goto66:	JMP			RegMacroShortName
@Goto67:	JMP			RegSetHandlerName
@Goto68:	JMP			ProxyRegister
@Goto69:	JMP			ProxyUnregister
@Goto70:	JMP			ProxyUnregisterAll
@Goto71:	JMP			ProxyCurrentApp
@Goto72:	JMP			ProxyGetCallInfo
@Goto73:	JMP			ProxyEventTime
@Goto74:	JMP			ProxyClass
@Goto75:	JMP			ProxySignal
@Goto76:	JMP			StringDateTime
@Goto77:	JMP			StringDate
@Goto78:	JMP			StringTime


// This name identifies the library.  Apps can pass it to 
// SysLibFind() to check if the library is already installed.
@Name:		DC.B		LibName

}

