#include <PalmOS.h>			// Includes all Palm OS headers
#include "pdQCore.h"
#include "pdQRegistry.h"

#define BUILDING_THIS_LIB	// Defined in this file only...
#include "NSBKyocera.h"		// Library public definitions

#define THIS_REQUIRES_GLOBALS
#ifdef THIS_REQUIRES_GLOBALS
	#include "NSBKyocera_Globals.h"
#else
	#define THIS_ALLOCATE_GLOBALS
	#define THIS_FREE_GLOBALS
	#define THIS_ATTACH_GLOBALS
	#define THIS_DETACH_GLOBALS
#endif


/********************************************************************
 *                            D b l S y s V e r
 ********************************************************************/
double DblSysVer(UInt32 ver) {	
	Int32 major;
	Int32 minor;
	char  majorStr[16];
	char  minorStr[16];
	char  verStr[32];
	FlpCompDouble uDbl;
	
	major = sysGetROMVerMajor(ver);
	minor = sysGetROMVerMinor(ver);
    StrIToA(majorStr, major);
    StrIToA(minorStr, minor);
    StrCopy(verStr, majorStr);
    StrCat(verStr, ".");
    StrCat(verStr, minorStr);
    uDbl.fd = FlpAToF(verStr);
    
	return uDbl.d;
}

/********************************************************************
 *                         U I n t C r e a t o r
 ********************************************************************/
UInt32 UIntCreator(char *sCreator) {
    return ((sCreator[0] * 16777216)
          + (sCreator[1] * 65536)
          + (sCreator[2] * 256)
          + sCreator[3]);
}

/********************************************************************
 *                           V e r s i o n
 ********************************************************************/

Err Version(UInt16 refNum, double *version) {	
	
	*version = 1.1;
	return 0;
}

/********************************************************************
 *                         C o m p i l e I n f o
 ********************************************************************/

Err CompileInfo(UInt16 refNum, char *compileDate, char *compileTime) {	
	
	StrCopy(compileDate, __DATE__);
	StrCopy(compileTime, __TIME__);
	return 0;
}

/********************************************************************
 *                      C o r e L i b P r e s e n t
 ********************************************************************/
Err CoreLibPresent(UInt16 refNum, Int32 *boolean) {	
	THIS_ATTACH_GLOBALS
	
	if (gP->coreRefNum == sysInvalidRefNum)
	    *boolean = 0;
	else
	    *boolean = 1;

    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                  R e g i s t r y L i b P r e s e n t
 ********************************************************************/
Err RegistryLibPresent(UInt16 refNum, Int32 *boolean) {	
	THIS_ATTACH_GLOBALS
	
	if (gP->registryRefNum == sysInvalidRefNum)
	    *boolean = 0;
	else
	    *boolean = 1;

    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                  C o r e L i b G e t V e r s i o n
 ********************************************************************/
Err CoreLibGetVersion(UInt16 refNum, double *version) {	
	Err status;
	UInt32 ver;
	THIS_ATTACH_GLOBALS
	
	status = PDQCoreLibGetVersion(gP->coreRefNum, &ver);
    *version = DblSysVer(ver);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                        S i g R e g i s t e r
 ********************************************************************/
Err SigRegister(UInt16 refNum, Int32 uClass, Int32 uMask,
                Int32 nPriority, char *sCreator, Int32 *result) {	
	Err status;
	UInt32 uCreator;
	THIS_ATTACH_GLOBALS
	
	uCreator = UIntCreator(sCreator);
	status = PDQSigRegister(gP->coreRefNum, (UInt32) uClass, (UInt32) uMask,
	                        (SigPriorityType) nPriority,
	                        uCreator, sysFileTApplication);
    *result = (Int32) status;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                        S i g U n r e g i s t e r
 ********************************************************************/
Err SigUnregister(UInt16 refNum, Int32 uClass, Int32 uMask,
                  char *sCreator, Int32 *result) {	
	Err status;
	UInt32 uCreator;
	THIS_ATTACH_GLOBALS
	
	uCreator = UIntCreator(sCreator);
	status = PDQSigUnregister(gP->coreRefNum, (UInt32) uClass, (UInt32) uMask,
	                          uCreator, sysFileTApplication);
    *result = (Int32) status;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                         C B E n u m S i g n a l s
 ********************************************************************/
Boolean CBEnumSignals(void *pContext, UInt32 uClass, UInt32 uMask, SigPriorityType priority,
                      UInt32 uCreator, UInt32 uType) {
    UInt16 refNum = *((UInt16 *) pContext);
	THIS_ATTACH_GLOBALS
	
	gP->enumCount++;
	if (gP->number == gP->enumCount)  {
		gP->sigClass = uClass;
		gP->mask = uMask;
		gP->priority = priority;
		gP->creator = uCreator;
		gP->type = uType;
	    THIS_DETACH_GLOBALS
	    return false;
	}
	else {
	    THIS_DETACH_GLOBALS
	    return true;
	}
}
                
/********************************************************************
 *                         S i g E n u m e r a t e
 ********************************************************************/
Err SigEnumerate(UInt16 refNum, Int32 number, Int32 inClass, Int32 sigMask, char *name, Int32 *outClass) {
    Boolean status;
	THIS_ATTACH_GLOBALS
	
	gP->enumCount = 0;
	gP->number = number;
	gP->sigClass = -1;
	gP->mask = -1;
	gP->priority = 255;
    gP->creator = 0;
    gP->type = -1;
	status = PDQSigEnumerate(gP->coreRefNum, (UInt32) inClass, (UInt32) sigMask, name, (void *) &refNum, CBEnumSignals);
	*outClass = (Int32) gP->sigClass;
	    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                             S i g M a s k
 ********************************************************************/
Err SigMask(UInt16 refNum, Int32 *sigMask) {
	THIS_ATTACH_GLOBALS

    *sigMask = (Int32) gP->mask;
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                             S i g P r i o r i t y
 ********************************************************************/
Err SigPriority(UInt16 refNum, Int32 *sigPriority) {
	THIS_ATTACH_GLOBALS

    *sigPriority = (Int32) gP->priority;
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                             S i g C r e a t o r
 ********************************************************************/
Err SigCreator(UInt16 refNum, char *sigCreator) {
    CreatorUnion cuCreator;
	THIS_ATTACH_GLOBALS

    cuCreator.uCreator = gP->creator;
    sigCreator[0] = cuCreator.sCreator[0];
    sigCreator[1] = cuCreator.sCreator[1];
    sigCreator[2] = cuCreator.sCreator[2];
    sigCreator[3] = cuCreator.sCreator[3];
    sigCreator[4] = 0;	
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                             S i g T y p e
 ********************************************************************/
Err SigType(UInt16 refNum, Int32 *sigType) {
	THIS_ATTACH_GLOBALS

    *sigType = (Int32) gP->type;
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                            M o d P o w e r
 ********************************************************************/
Err ModPower(UInt16 refNum, Int32 boolean) {
	Err status;
	THIS_ATTACH_GLOBALS
	
	status = PDQModPower(gP->coreRefNum, (Boolean) boolean);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                    M o d S e t E a r V o l u m e
 ********************************************************************/
Err ModSetEarVolume(UInt16 refNum, Int32 adjust, Int32 *volume) {
	Err status;
	Int16 value;
	THIS_ATTACH_GLOBALS
	
	status = PDQModSetEarVolume(gP->coreRefNum, (Int16) adjust, &value);
    *volume = (Int32) value;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                         M o d G e t S t a t e
 ********************************************************************/
Err ModGetState(UInt16 refNum, Int32 *state) {
	THIS_ATTACH_GLOBALS
	
	*state = (Int32) PDQModGetState(gP->coreRefNum);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                     M o d S t a t e P o w e r e d
 ********************************************************************/
Err ModStatePowered(UInt16 refNum, Int32 *powered) {
	THIS_ATTACH_GLOBALS
	
	*powered = (Int32) (PDQModGetState(gP->coreRefNum) & MSTATE_POWERED);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                     M o d S t a t e I n C a l l
 ********************************************************************/
Err ModStateInCall(UInt16 refNum, Int32 *inCall) {
	THIS_ATTACH_GLOBALS
	
	*inCall = (Int32) (PDQModGetState(gP->coreRefNum) & MSTATE_INCALL);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                     M o d S t a t e A M P S
 ********************************************************************/
Err ModStateAMPS(UInt16 refNum, Int32 *AMPS) {
	THIS_ATTACH_GLOBALS
	
	*AMPS = (Int32) (PDQModGetState(gP->coreRefNum) & MSTATE_AMPS);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                     M o d S t a t e N o S e r v i c e
 ********************************************************************/
Err ModStateNoService(UInt16 refNum, Int32 *noService) {
	THIS_ATTACH_GLOBALS
	
	*noService = (Int32) (PDQModGetState(gP->coreRefNum) & MSTATE_NOSERVICE);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                     M o d S t a t e H a r d P a u s e d
 ********************************************************************/
Err ModStateHardPaused(UInt16 refNum, Int32 *hardPaused) {
	THIS_ATTACH_GLOBALS
	
	*hardPaused = (Int32) (PDQModGetState(gP->coreRefNum) & MSTATE_HARD_PAUSED);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                     M o d S t a t e M u t e d
 ********************************************************************/
Err ModStateMuted(UInt16 refNum, Int32 *muted) {
	THIS_ATTACH_GLOBALS
	
	*muted = (Int32) (PDQModGetState(gP->coreRefNum) & MSTATE_MUTED);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                     M o d S t a t e L P M
 ********************************************************************/
Err ModStateLPM(UInt16 refNum, Int32 *LPM) {
	THIS_ATTACH_GLOBALS
	
	*LPM = (Int32) (PDQModGetState(gP->coreRefNum) & MSTATE_LPM);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                            M o d M u t e
 ********************************************************************/
Err ModMute(UInt16 refNum, Int32 boolean) {
	Err status;
	THIS_ATTACH_GLOBALS
	
	status = PDQModMute(gP->coreRefNum, (Boolean) boolean);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                      M o d G e t P h o n e N u m b e r
 ********************************************************************/
Err ModGetPhoneNumber(UInt16 refNum, char *phoneNumber) {
	Err status;
	char pNumber[MAX_DIGITS + 1];
	THIS_ATTACH_GLOBALS
	
	status = PDQModGetPhoneNumber(gP->coreRefNum, pNumber);
	if (status == PDQErrNoError)
	    StrCopy(phoneNumber, pNumber);
	else
		StrCopy(phoneNumber, "");
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                         T e l M a k e C a l l
 ********************************************************************/
Err TelMakeCall(UInt16 refNum, char *phoneNumber, Int32 *status) {
	THIS_ATTACH_GLOBALS
	
	if (phoneNumber[0] == 0)
		*status = (Int32) PDQTelMakeCall(gP->coreRefNum, NULL);
	else
		*status = (Int32) PDQTelMakeCall(gP->coreRefNum, phoneNumber);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                         T e l E n d C a l l
 ********************************************************************/
Err TelEndCall(UInt16 refNum, Int32 *status) {
	THIS_ATTACH_GLOBALS
	
	*status = (Int32) PDQTelEndCall(gP->coreRefNum);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                     T e l A n s w e r C a l l
 ********************************************************************/
Err TelAnswerCall(UInt16 refNum, Int32 *status) {
	THIS_ATTACH_GLOBALS
	
	*status = (Int32) PDQTelAnswerCall(gP->coreRefNum);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                    T e l G e n e r a t e D T M F
 ********************************************************************/
Err TelGenerateDTMF(UInt16 refNum, char *key, Int32 bLong, Int32 *status) {
	THIS_ATTACH_GLOBALS
	
	*status = (Int32) PDQTelGenerateDTMF(gP->coreRefNum, (UInt8) key[0], (Boolean) bLong);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                    T e l G e t C a l l I n f o
 ********************************************************************/
Err TelGetCallInfo(UInt16 refNum, Int32 *status) {
	THIS_ATTACH_GLOBALS
	
	*status = (Int32) PDQTelGetCallInfo(gP->coreRefNum, &gP->callInfo);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                    T e l C I S i g n a l H i s t
 ********************************************************************/
Err TelCISignalHist(UInt16 refNum, Int32 *signalHist) {
	THIS_ATTACH_GLOBALS
	
	*signalHist = (Int32) gP->callInfo.dwSignalHist;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                    T e l C I C a l l F l a g s
 ********************************************************************/
Err TelCICallFlags(UInt16 refNum, Int32 *callFlags) {
	THIS_ATTACH_GLOBALS
	
	*callFlags = (Int32) gP->callInfo.callFlags;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *               T e l C I C a l l e r I D S t a t u s
 ********************************************************************/
Err TelCICallerIDStatus(UInt16 refNum, Int32 *callerIDStatus) {
	THIS_ATTACH_GLOBALS
	
	*callerIDStatus = (Int32) gP->callInfo.nCallerIDStatus;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                   T e l C I D i a l i n g P a u s e d
 ********************************************************************/
Err TelCIDialingPaused(UInt16 refNum, Int32 *dialingPaused) {
	THIS_ATTACH_GLOBALS
	
	*dialingPaused = (Int32) gP->callInfo.bDialingPaused;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                          T e l C I N u m b e r
 ********************************************************************/
Err TelCINumber(UInt16 refNum, char *number) {
	THIS_ATTACH_GLOBALS
	
	StrCopy(number, gP->callInfo.szNumber);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                   T e l C I T i m e O f C a l l
 ********************************************************************/
Err TelCITimeOfCall(UInt16 refNum, Int32 *timeOfCall) {
	THIS_ATTACH_GLOBALS
	
	*timeOfCall = (Int32) gP->callInfo.lTimeOfCall;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                   T e l C I C a l l D u r a t i o n
 ********************************************************************/
Err TelCICallDuration(UInt16 refNum, Int32 *callDuration) {
	THIS_ATTACH_GLOBALS
	
	*callDuration = (Int32) gP->callInfo.lCallDuration;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                          T e l C I W a i t i n g
 ********************************************************************/
Err TelCIWaiting(UInt16 refNum, char *waiting) {
	THIS_ATTACH_GLOBALS
	
	StrCopy(waiting, gP->callInfo.szWaiting);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                             T e l C I E x t
 ********************************************************************/
Err TelCIExt(UInt16 refNum, char *ext) {
	THIS_ATTACH_GLOBALS
	
	StrCopy(ext, gP->callInfo.szExt);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                              T e l C I E r r
 ********************************************************************/
Err TelCIErr(UInt16 refNum, Int32 *err) {
	THIS_ATTACH_GLOBALS
	
	*err = (Int32) gP->callInfo.nErr;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                        T e l C I C a l l T y p e
 ********************************************************************/
Err TelCICallType(UInt16 refNum, Int32 *callType) {
	THIS_ATTACH_GLOBALS
	
	*callType = (Int32) gP->callInfo.dataCallInfo.callType;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                        T e l C I B a u d R a t e
 ********************************************************************/
Err TelCIBaudRate(UInt16 refNum, Int32 *baudRate) {
	THIS_ATTACH_GLOBALS
	
	*baudRate = (Int32) gP->callInfo.dataCallInfo.dwBaudRate;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                  T e l R e s u m e D i a l i n g
 ********************************************************************/
Err TelResumeDialing(UInt16 refNum) {
    Err status;
	THIS_ATTACH_GLOBALS
	
	status = PDQTelResumeDialing(gP->coreRefNum);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                     T e l C a n c e l P a u s e
 ********************************************************************/
Err TelCancelPause(UInt16 refNum) {
    Err status;
	THIS_ATTACH_GLOBALS
	
	status = PDQTelCancelPause(gP->coreRefNum);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                     T e l F o r m a t N u m b e r
 ********************************************************************/
Err TelFormatNumber(UInt16 refNum, char *unformatted, Int32 flags, char *formatted) {
    char *invalid;
    char pszDest[MAX_DIGITS + 1];
	THIS_ATTACH_GLOBALS
	
	invalid = PDQTelFormatNumber(gP->coreRefNum, unformatted, pszDest, 
	                             sizeof(pszDest), (UInt16) flags);
	if (*invalid != 0) {
		//StrCopy(pszInvalid, "ERR@");
		StrCopy(formatted, invalid);
	}
	else
	    StrCopy(formatted, pszDest);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                         T e l G e t D i g i t
 ********************************************************************/
Err TelGetDigit(UInt16 refNum, char *inChar, char *outChar) {
	Char ch;
	Char digit;
	Boolean valid;
	THIS_ATTACH_GLOBALS
	
	ch = *inChar;
	digit = PDQTelGetDigit(gP->coreRefNum, ch, &valid);
	if (valid)
	{
		outChar[0] = digit;
		outChar[1] = 0;
	}
	else
		StrCopy(outChar, "");
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                       R e g G e t V e r s i o n
 ********************************************************************/
Err RegGetVersion(UInt16 refNum, double *version) {	
	Err status;
	UInt32 ver;
	THIS_ATTACH_GLOBALS
	
	status = PDQRegGetVersion(gP->registryRefNum, &ver);
    *version = DblSysVer(ver);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                         R e g A d d S c h e m e
 ********************************************************************/
Err RegAddScheme(UInt16 refNum, char *scheme, char *creator, Int32 capFlags, Int32 *status) {	
	UInt32 uCreator;
	THIS_ATTACH_GLOBALS
	
	uCreator = UIntCreator(creator);
	*status = PDQRegAddScheme(gP->registryRefNum, scheme, uCreator, (UInt32) capFlags);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                      R e g R e m o v e S c h e m e
 ********************************************************************/
Err RegRemoveScheme(UInt16 refNum, char *scheme, char *creator, Int32 *status) {	
	UInt32 uCreator;
	THIS_ATTACH_GLOBALS
	
	uCreator = UIntCreator(creator);
	*status = PDQRegRemoveScheme(gP->registryRefNum, scheme, uCreator);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                      R e g E n a b l e S c h e m e
 ********************************************************************/
Err RegEnableScheme(UInt16 refNum, char *scheme, char *creator, Int32 enable, Int32 *status) {	
	UInt32 uCreator;
	THIS_ATTACH_GLOBALS
	
	uCreator = UIntCreator(creator);
	*status = PDQRegEnableScheme(gP->registryRefNum, scheme, uCreator, (Boolean) enable);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                         C B E n u m S c h e m e s
 ********************************************************************/
Boolean CBEnumSchemes(void *pUser, Char *pszScheme, Char *pszName, Char *pszShortName,
                      UInt32 uCreator, UInt32 dwFlags, Boolean bEnabled) {
    UInt16 refNum = *((UInt16 *) pUser);
	THIS_ATTACH_GLOBALS
	gP->enumCount++;
	if (gP->number == gP->enumCount)  {
	    StrCopy(gP->scheme, pszScheme);
	    StrCopy(gP->name, pszName);
	    StrCopy(gP->shortName, pszShortName);
	    gP->creator = uCreator;
	    gP->flags = dwFlags;
	    gP->enabled = bEnabled;
	    THIS_DETACH_GLOBALS
	    return false;
	}
	else {
	    THIS_DETACH_GLOBALS
	    return true;
	}
}
                
/********************************************************************
 *                         R e g E n u m S c h e m e s
 ********************************************************************/
Err RegEnumSchemes(UInt16 refNum, Int32 number, char *scheme) {
    Err status;
	THIS_ATTACH_GLOBALS
	
	gP->enumCount = 0;
	gP->number = number;
    StrCopy(gP->scheme, "");
    StrCopy(gP->name, "");
    StrCopy(gP->shortName, "");
    gP->creator = 0;
    gP->flags = 0;
    gP->enabled = 0;
	status = PDQRegEnumSchemes(gP->registryRefNum, CBEnumSchemes, (void *) &refNum);
    StrCopy(scheme, gP->scheme);
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                         R e g S c h e m e N a m e
 ********************************************************************/
Err RegSchemeName(UInt16 refNum, char *name) {
	THIS_ATTACH_GLOBALS

    StrCopy(name, gP->name);	
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                    R e g S c h e m e S h o r t N a m e
 ********************************************************************/
Err RegSchemeShortName(UInt16 refNum, char *shortName) {
	THIS_ATTACH_GLOBALS

    StrCopy(shortName, gP->shortName);	
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                     R e g S c h e m e C r e a t o r
 ********************************************************************/
Err RegSchemeCreator(UInt16 refNum, char *creator) {
    CreatorUnion cuCreator;
	THIS_ATTACH_GLOBALS

    cuCreator.uCreator = gP->creator;
    creator[0] = cuCreator.sCreator[0];
    creator[1] = cuCreator.sCreator[1];
    creator[2] = cuCreator.sCreator[2];
    creator[3] = cuCreator.sCreator[3];
    creator[4] = 0;	
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                        R e g S c h e m e F l a g s
 ********************************************************************/
Err RegSchemeFlags(UInt16 refNum, Int32 *flags) {
	THIS_ATTACH_GLOBALS

    *flags = (Int32) gP->flags;	
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                      R e g S c h e m e E n a b l e d
 ********************************************************************/
Err RegSchemeEnabled(UInt16 refNum, Int32 *enabled) {
	THIS_ATTACH_GLOBALS

    *enabled = (Int32) gP->enabled;	
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                     R e g G e t H a n d l e r
 ********************************************************************/
Err RegGetHandler(UInt16 refNum, char *scheme, char *creator) {
    CreatorUnion cuCreator;
	THIS_ATTACH_GLOBALS

    cuCreator.uCreator = PDQRegGetSchemeHandler(gP->registryRefNum, scheme);
    creator[0] = cuCreator.sCreator[0];
    creator[1] = cuCreator.sCreator[1];
    creator[2] = cuCreator.sCreator[2];
    creator[3] = cuCreator.sCreator[3];
    creator[4] = 0;	
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                     R e g P r o c e s s U R L
 ********************************************************************/
Err RegProcessURL(UInt16 refNum, char *URL, Int32 *status) {
	THIS_ATTACH_GLOBALS

    *status = PDQRegProcessURL(gP->registryRefNum, URL);
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                R e g P r o c e s s M a i l A d d r e s s
 ********************************************************************/
Err RegProcessMailAddress(UInt16 refNum, char *firstName, char *lastName, char *address, Int32 *status) {
	THIS_ATTACH_GLOBALS

    *status = PDQRegProcessMailAddress(gP->registryRefNum, firstName, lastName, address);
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                         R e g A d d M a c r o
 ********************************************************************/
Err RegAddMacro(UInt16 refNum, char *URL, char *shortName, char *desc) {
    Err status;
	THIS_ATTACH_GLOBALS

    status = PDQRegAddMacro(gP->registryRefNum, URL, shortName, desc);
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                      R e g R e m o v e M a c r o
 ********************************************************************/
Err RegRemoveMacro(UInt16 refNum, char *URL) {
    Err status;
	THIS_ATTACH_GLOBALS

    status = PDQRegRemoveMacro(gP->registryRefNum, URL);
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                         C B E n u m M a c r o s
 ********************************************************************/
Boolean CBEnumMacros(void *pUser, Char *pszURL, Char *pszShortName, Char *pszDesc) {
    UInt16 refNum = *((UInt16 *) pUser);
	THIS_ATTACH_GLOBALS
	gP->enumCount++;
	if (gP->number == gP->enumCount)  {
	    StrCopy(gP->scheme, pszURL);
	    StrCopy(gP->name, pszDesc);
	    StrCopy(gP->shortName, pszShortName);
	    THIS_DETACH_GLOBALS
	    return false;
	}
	else {
	    THIS_DETACH_GLOBALS
	    return true;
	}
}
                
/********************************************************************
 *                         R e g E n u m M a c r o s
 ********************************************************************/
Err RegEnumMacros(UInt16 refNum, Int32 number, char *URL) {
    Err status;
	THIS_ATTACH_GLOBALS
	
	gP->enumCount = 0;
	gP->number = number;
    StrCopy(gP->scheme, "");
    StrCopy(gP->name, "");
    StrCopy(gP->shortName, "");
	status = PDQRegEnumMacros(gP->registryRefNum, CBEnumMacros, (void *) &refNum);
    StrCopy(URL, gP->scheme);
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                         R e g M a c r o D e s c
 ********************************************************************/
Err RegMacroDesc(UInt16 refNum, char *desc) {
	THIS_ATTACH_GLOBALS

    StrCopy(desc, gP->name);	
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                    R e g M a c r o S h o r t N a m e
 ********************************************************************/
Err RegMacroShortName(UInt16 refNum, char *shortName) {
	THIS_ATTACH_GLOBALS

    StrCopy(shortName, gP->shortName);	
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                R e g S e t H a n d l e r N a m e
 ********************************************************************/
Err RegSetHandlerName(UInt16 refNum, char *scheme, char *name, char *shortName, Int32 *status) {
	THIS_ATTACH_GLOBALS

    *status = PDQRegSetHandlerName(gP->registryRefNum, scheme, name, shortName);
	THIS_DETACH_GLOBALS
	return 0;
}

/********************************************************************
 *                        P r o x y R e g i s t e r
 ********************************************************************/
Err ProxyRegister(UInt16 refNum, Int32 uClass, Int32 uMask,
                Int32 nPriority, char *sCreator, Int32 *result) {	
    UInt16 cardNo;
    LocalID id;
    Err     status;
    DmSearchStateType state;
	UInt32 uCreator;
	RegisteredApps rA;
	UInt16 rASize;
	UInt16 i, n;
    UInt32 sigValues[3][12] = 
        {{SGN_TAPI_IDLE,SGN_TAPI_INCOMING,SGN_TAPI_LOST,SGN_TAPI_MISSED,SGN_TAPI_FAILED,SGN_TAPI_CALLING,SGN_TAPI_CONVERSATION,SGN_TAPI_ENDED,SGN_TAPI_DIALPAUSED,SGN_TAPI_CALLERID,SGN_TAPI_DIALEDDTMF,SGN_TAPI_INCOMINGMODE},
         {SGN_POWER,SGN_CHARGING,SGN_SERVICE,SGN_ROAM,SGN_VOICEPRIVACY,SGN_NAMCHANGED,SGN_RSSI,SGN_DIGITAL,SGN_LOCK,SGN_MODULEFAILURE,SGN_AIRTIMECHANGED,SGN_MUTED},
         {SGN_MSG_RAW_SMS,SGN_MSG_CARRIER_VOICE_MAIL,SGN_MSG_TEXT_MESSAGE,SGN_MSG_PAGE,0,0,0,0,0,0,0,0}};
	THIS_ATTACH_GLOBALS
	
	uCreator = UIntCreator(sCreator);
    status = DmGetNextDatabaseByTypeCreator(true, &state, 
                                            sysFileTApplication, uCreator, 
                                            true, &cardNo, &id);
    if (status != errNone) {
        *result = (Int32) status;
        THIS_DETACH_GLOBALS
        return 0;
    }
   	rASize = sizeof(rA);
	if (PrefGetAppPreferences(ProxyCreatorID, 1, 
                              &rA, &rASize, true) == noPreferenceFound) {
        rA.runningApp = 0;
        for (i = 0; i < 3; i++)
            for (n = 0; n < 12; n++) {
                rA.startApp[i][n] = 0;
                rA.priority[i][n] = 0;
            }
    }
    
    switch (uClass) {
        case SGN_CLASS_TAPI:
            i = 0;
            break;
        case SGN_CLASS_MSG:
            i = 1;
            break;
        case SGN_CLASS_MODULE:
        case 3:
            i = 2;
            break;
    }

    for (n = 0; n < 12; n++)
        if ((UInt32) uMask & sigValues[i][n]) {
                rA.startApp[i][n] = id;
                rA.priority[i][n] = (SigPriorityType) nPriority;
        }
    PrefSetAppPreferences(ProxyCreatorID, 1, 0, 
                          &rA, sizeof(rA), true);

	status = PDQSigRegister(gP->coreRefNum, (UInt32) uClass, (UInt32) uMask,
	                        (SigPriorityType) nPriority,
	                        ProxyCreatorID, sysFileTApplication);
    *result = (Int32) status;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                      P r o x y U n r e g i s t e r
 ********************************************************************/
Err ProxyUnregister(UInt16 refNum, Int32 uClass, Int32 uMask,
                    Int32 *result) {	
    Err     status;
	RegisteredApps rA;
	UInt16 rASize;
	UInt16 i, n;
    UInt32 sigValues[3][12] = 
        {{SGN_TAPI_IDLE,SGN_TAPI_INCOMING,SGN_TAPI_LOST,SGN_TAPI_MISSED,SGN_TAPI_FAILED,SGN_TAPI_CALLING,SGN_TAPI_CONVERSATION,SGN_TAPI_ENDED,SGN_TAPI_DIALPAUSED,SGN_TAPI_CALLERID,SGN_TAPI_DIALEDDTMF,SGN_TAPI_INCOMINGMODE},
         {SGN_POWER,SGN_CHARGING,SGN_SERVICE,SGN_ROAM,SGN_VOICEPRIVACY,SGN_NAMCHANGED,SGN_RSSI,SGN_DIGITAL,SGN_LOCK,SGN_MODULEFAILURE,SGN_AIRTIMECHANGED,SGN_MUTED},
         {SGN_MSG_RAW_SMS,SGN_MSG_CARRIER_VOICE_MAIL,SGN_MSG_TEXT_MESSAGE,SGN_MSG_PAGE,0,0,0,0,0,0,0,0}};
	THIS_ATTACH_GLOBALS
	
   	rASize = sizeof(rA);
	if (PrefGetAppPreferences(ProxyCreatorID, 1, 
                              &rA, &rASize, true) == noPreferenceFound) {
        rA.runningApp = 0;
        for (i = 0; i < 3; i++)
            for (n = 0; n < 12; n++) {
                rA.startApp[i][n] = 0;
                rA.priority[i][n] = 0;
            }
    }
    
    switch (uClass) {
        case SGN_CLASS_TAPI:
            i = 0;
            break;
        case SGN_CLASS_MSG:
            i = 1;
            break;
        case SGN_CLASS_MODULE:
        case 3:
            i = 2;
            break;
    }

    for (n = 0; n < 12; n++)
        if ((UInt32) uMask & sigValues[i][n]) {
                rA.startApp[i][n] = 0;
                rA.priority[i][n] = 0;
        }
    PrefSetAppPreferences(ProxyCreatorID, 1, 0, 
                          &rA, sizeof(rA), true);

	status = PDQSigUnregister(gP->coreRefNum, (UInt32) uClass, (UInt32) uMask,
                              ProxyCreatorID, sysFileTApplication);
    *result = (Int32) status;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                 P r o x y U n r e g i s t e r A l l
 ********************************************************************/
Err ProxyUnregisterAll(UInt16 refNum) {
    Err     status;
	RegisteredApps rA;
	UInt16 rASize;
	UInt16 i, n;
	THIS_ATTACH_GLOBALS
	
   	rASize = sizeof(rA);
	PrefGetAppPreferences(ProxyCreatorID, 1, 
                          &rA, &rASize, true);
    for (i = 0; i < 3; i++)
        for (n = 0; n < 12; n++) {
            rA.startApp[i][n] = 0;
            rA.priority[i][n] = 0;
        }
    
    PrefSetAppPreferences(ProxyCreatorID, 1, 0, 
                          &rA, sizeof(rA), true);

	status = PDQSigUnregister(gP->coreRefNum, SGN_CLASS_TAPI, SGN_ALL,
                              ProxyCreatorID, sysFileTApplication);
	status = PDQSigUnregister(gP->coreRefNum, SGN_CLASS_MSG, SGN_ALL,
                              ProxyCreatorID, sysFileTApplication);
	status = PDQSigUnregister(gP->coreRefNum, SGN_CLASS_MODULE, SGN_ALL,
                              ProxyCreatorID, sysFileTApplication);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                 P r o x y C u r r e n t A p p
 ********************************************************************/
Err ProxyCurrentApp(UInt16 refNum, Char *sCreator, Int32 *result) {
    Err     status;
	RegisteredApps rA;
	UInt16 rASize;
    UInt16 cardNo;
    LocalID id;
    DmSearchStateType state;
	UInt32 uCreator;
	UInt16 i, n;
	THIS_ATTACH_GLOBALS
	
	if (StrLen(sCreator) > 0) {
		uCreator = UIntCreator(sCreator);
    	status = DmGetNextDatabaseByTypeCreator(true, &state, 
        	                                    sysFileTApplication, uCreator, 
            	                                true, &cardNo, &id);
    }
    else {
        status = errNone;
        id = 0;
    }
    if (status != errNone) {
        *result = -1;
        THIS_DETACH_GLOBALS
        return 0;
    }
   	rASize = sizeof(rA);
	if (PrefGetAppPreferences(ProxyCreatorID, 1, 
                              &rA, &rASize, true) == noPreferenceFound) {
        rA.runningApp = 0;
        for (i = 0; i < 3; i++)
            for (n = 0; n < 12; n++) {
                rA.startApp[i][n] = 0;
                rA.priority[i][n] = 0;
            }
    }
    
    if (rA.runningApp == id)
        *result = 1;
    else
        *result = 0;
    
    rA.runningApp = id;
    PrefSetAppPreferences(ProxyCreatorID, 1, 0, 
                          &rA, sizeof(rA), true);
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                  P r o x y G e t C a l l I n f o
 ********************************************************************/
Err ProxyGetCallInfo(UInt16 refNum, Int32 *status) {
    EventData eD;
    UInt16 eDSize;
	THIS_ATTACH_GLOBALS

    eDSize = sizeof(EventData);
	if (PrefGetAppPreferences(ProxyCreatorID, 0, 
                              &eD, &eDSize, true) == noPreferenceFound) {
        *status = -1;
        THIS_DETACH_GLOBALS
        return 0;
    }
	gP->callInfo.dwSignalHist = eD.callInfo.dwSignalHist;
	gP->callInfo.callFlags = eD.callInfo.callFlags;
	gP->callInfo.nCallerIDStatus = eD.callInfo.nCallerIDStatus;
	gP->callInfo.bDialingPaused = eD.callInfo.bDialingPaused;
	StrCopy(gP->callInfo.szNumber, eD.callInfo.szNumber);
	gP->callInfo.lTimeOfCall = eD.callInfo.lTimeOfCall;
    gP->callInfo.lCallDuration = eD.callInfo.lCallDuration;
	StrCopy(gP->callInfo.szWaiting, eD.callInfo.szWaiting);
	StrCopy(gP->callInfo.szExt, eD.callInfo.szExt);
	gP->callInfo.nErr = eD.callInfo.nErr;
	gP->callInfo.dataCallInfo.callType = eD.callInfo.dataCallInfo.callType;
	gP->callInfo.dataCallInfo.dwBaudRate = eD.callInfo.dataCallInfo.dwBaudRate;
	
	*status = 0;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                  P r o x y E v e n t T i m e
 ********************************************************************/
Err ProxyEventTime(UInt16 refNum, Int32 *sysTime) {
    EventData eD;
    UInt16 eDSize;
	THIS_ATTACH_GLOBALS

    eDSize = sizeof(EventData);
	if (PrefGetAppPreferences(ProxyCreatorID, 0, 
                              &eD, &eDSize, true) == noPreferenceFound) {
        *sysTime = -1;
        THIS_DETACH_GLOBALS
        return 0;
    }
	
	*sysTime = eD.eventTime;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                       P r o x y C l a s s
 ********************************************************************/
Err ProxyClass(UInt16 refNum, Int32 *signalClass) {
    EventData eD;
    UInt16 eDSize;
	THIS_ATTACH_GLOBALS

    eDSize = sizeof(EventData);
	if (PrefGetAppPreferences(ProxyCreatorID, 0, 
                              &eD, &eDSize, true) == noPreferenceFound) {
        *signalClass = -1;
        THIS_DETACH_GLOBALS
        return 0;
    }
	
	*signalClass = eD.signalClass;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                       P r o x y S i g n a l
 ********************************************************************/
Err ProxySignal(UInt16 refNum, Int32 *signal) {
    EventData eD;
    UInt16 eDSize;
	THIS_ATTACH_GLOBALS

    eDSize = sizeof(EventData);
	if (PrefGetAppPreferences(ProxyCreatorID, 0, 
                              &eD, &eDSize, true) == noPreferenceFound) {
        *signal = -1;
        THIS_DETACH_GLOBALS
        return 0;
    }
	
	*signal = eD.signal;
    
    THIS_DETACH_GLOBALS
	return 0 ;
}

/********************************************************************
 *                       S t r i n g D a t e T i m e
 ********************************************************************/
Err StringDateTime(UInt16 refNum, 
                   UInt32 sysTime,
                   Int32 ToDateFormat,
                   Int32 ToTimeFormat,
                   Int32 AMPMFormat,
                   char *strDateTime) {
    char         dtStr[32];
    char         tStr[32];
    
    dtStr[0] = 0;
    if (sysTime == 0)
        sysTime = TimGetSeconds();
    StringDate(refNum, sysTime, ToDateFormat, dtStr);
    StringTime(refNum, sysTime, ToTimeFormat, AMPMFormat, tStr);
    StrCat(dtStr, " ");
    StrCat(dtStr, tStr);

    StrCopy(strDateTime, dtStr);
    return 0;
}

/********************************************************************
 *                         S t r i n g D a t e
 ********************************************************************/
Err StringDate(UInt16 refNum, 
               UInt32 sysTime,
               Int32 ToDateFormat,
               char *strDate) {
    DateTimeType dt;
    char         dtStr[32];
    char         tStr[32];
    
    dtStr[0] = 0;
    if (sysTime == 0)
        sysTime = TimGetSeconds();
    TimSecondsToDateTime(sysTime, &dt);
    if (ToDateFormat) {
        StrIToA(tStr, dt.year);
        StrCat(dtStr, tStr);
        StrCat(dtStr, "/");
        StrIToA(tStr, dt.month);
        if (dt.month < 10)
            StrCat(dtStr, "0");
        StrCat(dtStr, tStr);
        StrCat(dtStr, "/");
        StrIToA(tStr, dt.day);
        if (dt.day < 10)
            StrCat(dtStr, "0");
        StrCat(dtStr, tStr);
    }
    else {
        StrIToA(tStr, dt.month);
        if (dt.month < 10)
            StrCat(dtStr, "0");
        StrCat(dtStr, tStr);
        StrCat(dtStr, "/");
        StrIToA(tStr, dt.day);
        if (dt.day < 10)
            StrCat(dtStr, "0");
        StrCat(dtStr, tStr);
        StrCat(dtStr, "/");
        if (dt.year > 1999)
            dt.year = dt.year - 2000;
        else
            dt.year = dt.year - 1900;
        StrIToA(tStr, dt.year);
        if (dt.year < 10)
            StrCat(dtStr, "0");
        StrCat(dtStr, tStr);
    }
            
    StrCopy(strDate, dtStr);
    return 0;
}

/********************************************************************
 *                          S t r i n g T i m e
 ********************************************************************/
Err StringTime(UInt16 refNum, 
               UInt32 sysTime,
               Int32 ToTimeFormat,
               Int32 AMPMFormat,
               char *strTime) {
    DateTimeType dt;
    char         dtStr[32];
    char         tStr[32];
    
    dtStr[0] = 0;
    if (sysTime == 0)
        sysTime = TimGetSeconds();
    TimSecondsToDateTime(sysTime, &dt);
    if (AMPMFormat) {
        if (dt.hour > 12)
            StrIToA(tStr, dt.hour - 12);
        else
            StrIToA(tStr, dt.hour);
    }
    else
        StrIToA(tStr, dt.hour);
    if (dt.hour < 10)
        StrCat(dtStr, "0");
    StrCat(dtStr, tStr);
    StrCat(dtStr, ":");
    StrIToA(tStr, dt.minute);
    if (dt.minute < 10)
        StrCat(dtStr, "0");
    StrCat(dtStr, tStr);
    if (ToTimeFormat) {
        StrCat(dtStr, ":");
        StrIToA(tStr, dt.second);
        if (dt.second < 10)
            StrCat(dtStr, "0");
        StrCat(dtStr, tStr);
    }
    if (AMPMFormat)
        if (dt.hour > 12)
            StrCat(dtStr, " PM");
        else
            StrCat(dtStr, " AM");
            
    StrCopy(strTime, dtStr);
    return 0;
}

/*###################################################################
 #       S t a n d a r d ,  R E Q U I R E D    F u n c t i o n s
 #
 #   You should not need to modify these functions.  Put your
 #   library's custom functions before these to separate your custom
 #   code from the standard, required code.  This way, the code you 
 #   need to modify is easily found at the top of the file and you 
 #   can "ignore" the standard, required, code at the end of the file.
 ####################################################################
 #
 #   T H I S _ L i b O p e n , C l o s e , S l e e p , & W a k e
 #
 #   The following four functions, THIS_LibOpen, THIS_LibClose,
 #   THIS_LibSleep, and THIS_LibWake are standard, REQUIRED
 #   functions for a Shared Library.  If you are using "globals" 
 #   and you want to initialize them to something other than 0, 
 #   then modify the function PrvMakeGlobals in the 
 #   "THIS_LibGlobals.h" header file.
 #*/

Err THIS_LibOpen(UInt16 refNum) {
	Err	err = 0;
	THIS_ALLOCATE_GLOBALS	// Define local variables before this
	
	return err;
}

Err THIS_LibClose(UInt16 refNum) {
	Err	err = 0;
	THIS_FREE_GLOBALS	// Define local variables before this

	return err;
}

Err THIS_LibSleep(UInt16 refNum) {
	return 0;
}

Err THIS_LibWake(UInt16 refNum) {
	return 0;
}

/*###################################################################*/
