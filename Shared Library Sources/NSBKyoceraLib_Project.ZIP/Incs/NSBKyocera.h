#ifndef __THIS_LIB_H__
#define __THIS_LIB_H__


#ifdef BUILDING_THIS_LIB
	#define THIS_LIB_TRAP(trapNum)
#else
	#define THIS_LIB_TRAP(trapNum) SYS_TRAP(trapNum)
#endif

#include "pdQCore.h"


// Palm OS common definitions
#include <PalmTypes.h>
#include <SystemResources.h>


typedef struct {
	UInt32                   eventTime;
	Boolean                  started;
	UInt32                   signalClass;
	UInt32                   signal;
	CallInfoType             callInfo;
	AirTimeType              airTime;
	char                     szArg[MAX_DIGITS + 1];
	UInt32		             dwArg;
	Boolean                  bArg;
	Int16		             nArg;
	MsgSigType               msgInfo;
	char                     szMessage[250];
}  EventData;

typedef struct {
    LocalID runningApp;
    Boolean exclusive;
    Int16   waitTime;
    LocalID startApp[3][12];
    SigPriorityType priority[3][12];
} RegisteredApps;

/********************************************************************
 * Creator ID, Type, and Name of THIS Shared Library
 ********************************************************************/
#define		LibCreatorID	'NSBk'
#define		LibTypeID		'libr'
#define		LibName			"NSBKyoceraLib.lib"

#define     ProxyCreatorID  'nsbK'



/************************************************************
 * Library result codes:
 * (appErrorClass is reserved for 3rd party apps/libraries.
 * It is defined in SystemMgr.h)
 *************************************************************/

#define THIS_ErrParam		(appErrorClass | 1)		// invalid parameter
#define THIS_ErrNotOpen 	(appErrorClass | 2)		// library is not open
#define THIS_ErrStillOpen	(appErrorClass | 3)		// returned from THIS_LibClose() if
													// the library is still open by others
#define THIS_ErrMemory		(appErrorClass | 4)		// memory error occurred


//-----------------------------------------------------------------------------
//   Library function trap ID's:
//   Each library call gets a trap number.
//   THIS_TrapXXXX serves as an index into the library's dispatch
//   table.  The constant sysLibTrapCustom is the first available
//   trap number after the system predefined library traps Open,
//   Close, Sleep, & Wake.
//
//   WARNING!!! The order of these traps MUST match the order of 
//   the dispatch table in NSBKyocera_Dispatch.c!!!
//-----------------------------------------------------------------------------

typedef enum {
	TrapVersion = sysLibTrapCustom,
	TrapCompileInfo,
	TrapCoreLibPresent,
	TrapRegistryLibPresent,
	TrapCoreLibGetVersion,
	TrapSigRegister,
	TrapSigUnregister,
	TrapSigEnumerate,
	TrapSigMask,
	TrapSigPriority,
	TrapSigCreator,
	TrapSigType,
	TrapModPower,
	TrapModSetEarVolume,
	TrapModGetState,
	TrapModStatePowered,
	TrapModStateInCall,
	TrapModStateAMPS,
	TrapModStateNoService,
	TrapModStateHardPaused,
	TrapModStateMuted,
	TrapModStateLPM,
	TrapModMute,
	TrapModGetPhoneNumber,
	TrapTelMakeCall,
	TrapTelEndCall,
	TrapTelAnswerCall,
	TrapTelGenerateDTMF,
	TrapTelGetCallInfo,
	TrapTelCISignalHist,
	TrapTelCICallFlags,
	TrapTelCICallerIDStatus,
	TrapTelCIDialingPaused,
	TrapTelCINumber,
	TrapTelCITimeOfCall,
	TrapTelCICallDuration,
	TrapTelCIWaiting,
	TrapTelCIExt,
	TrapTelCIErr,
	TrapTelCICallType,
	TrapTelCIBaudRate,	
	TrapTelResumeDialing,
	TrapTelCancelPause,
	TrapTelFormatNumber,
	TrapTelGetDigit,
	TrapRegGetVersion,
	TrapRegAddScheme,
	TrapRegRemoveScheme,
	TrapRegEnableScheme,
	TrapRegEnumSchemes,
	TrapRegSchemeName,
	TrapRegSchemeShortName,
	TrapRegSchemeCreator,
	TrapRegSchemeFlags,
	TrapRegSchemeEnabled,
	TrapRegGetHandler,
	TrapRegProcessURL,
	TrapRegProcessMailAddress,
	TrapRegAddMacro,
	TrapRegRemoveMacro,
	TrapRegEnumMacros,
	TrapRegMacroDesc,
	TrapRegMacroShortName,
	TrapRegSetHandlerName,
	TrapProxyRegister,
	TrapProxyUnregister,
	TrapProxyUnregisterAll,
	TrapProxyCurrentApp,
	TrapProxyGetCallInfo,
	TrapProxyEventTime,
	TrapProxyClass,
	TrapProxySignal,
	TrapStringDateTime,
	TrapStringDate,
	TrapStringTime,
	
	TrapLast
	} THIS_TrapEnum;


/********************************************************************
 * API Prototypes
 ********************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

double DblSysVer(UInt32 ver);
UInt32 UIntCreator(char *sCreator);
Boolean CBEnumSchemes(void *pUser, Char *pszScheme, Char *pszName, Char *pszShortName,
                      UInt32 uCreator, UInt32 dwFlags, Boolean bEnabled);
Boolean CBEnumMacros(void *pUser, Char *pszURL, Char *pszShortName, Char *pszDesc);
Boolean CBEnumSignals(void *pContext, UInt32 uClass, UInt32 uMask, SigPriorityType priority,
                      UInt32 uCreator, UInt32 uType);

typedef union {
	UInt32 uCreator;
	char   sCreator[4];
	} CreatorUnion;
	
//--------------------------------------------------
// Custom library API functions
//--------------------------------------------------
	
extern Err Version(UInt16 refNum, double *version)
				THIS_LIB_TRAP(TrapVersion);
	
extern Err CompileInfo(UInt16 refNum, char *compileData, char *compileTime)
				THIS_LIB_TRAP(TrapCompileInfo);

extern Err CoreLibPresent(UInt16 refNum, Int32 *boolean)
				THIS_LIB_TRAP(TrapCoreLibPresent);

extern Err RegistryLibPresent(UInt16 refNum, Int32 *boolean)
				THIS_LIB_TRAP(TrapRegistryLibPresent);

extern Err CoreLibGetVersion(UInt16 refNum, double *version)
				THIS_LIB_TRAP(TrapCoreLibGetVersion);

extern Err SigRegister(UInt16 refNum, Int32 uClass, Int32 uMask,
                Int32 nPriority, char *sCreator, Int32 *result) 	
				THIS_LIB_TRAP(TrapSigRegister);
				
extern Err SigUnregister(UInt16 refNum, Int32 uClass, Int32 uMask,
                  char *sCreator, Int32 *result) 	
			  	THIS_LIB_TRAP(TrapSigUnregister);

extern Err SigEnumerate(UInt16 refNum, Int32 number, Int32 inClass, Int32 sigMask, char *name, Int32 *outClass)
			  	THIS_LIB_TRAP(TrapSigEnumerate);

extern Err SigMask(UInt16 refNum, Int32 *sigMask)
			  	THIS_LIB_TRAP(TrapSigMask);

extern Err SigPriority(UInt16 refNum, Int32 *sigPriority)
			  	THIS_LIB_TRAP(TrapSigPriority);

extern Err SigCreator(UInt16 refNum, char *sigCreator)
			  	THIS_LIB_TRAP(TrapSigCreator);

extern Err SigType(UInt16 refNum, Int32 *sigType)
			  	THIS_LIB_TRAP(TrapSigType);

extern Err ModPower(UInt16 refNum, Int32 boolean)
			  	THIS_LIB_TRAP(TrapModPower);

extern Err ModSetEarVolume(UInt16 refNum, Int32 adjust, Int32 *volume)
			  	THIS_LIB_TRAP(TrapModSetEarVolume);

extern Err ModGetState(UInt16 refNum, Int32 *state)
			  	THIS_LIB_TRAP(TrapModGetState);

extern Err ModStatePowered(UInt16 refNum, Int32 *powered)
			  	THIS_LIB_TRAP(TrapModStatePowered);

extern Err ModStateInCall(UInt16 refNum, Int32 *inCall)
			  	THIS_LIB_TRAP(TrapModStateInCall);

extern Err ModStateAMPS(UInt16 refNum, Int32 *AMPS)
			  	THIS_LIB_TRAP(TrapModStateAMPS);

extern Err ModStateNoService(UInt16 refNum, Int32 *noService)
			  	THIS_LIB_TRAP(TrapModStateNoService);

extern Err ModStateHardPaused(UInt16 refNum, Int32 *hardPaused)
			  	THIS_LIB_TRAP(TrapModStateHardPaused);

extern Err ModStateMuted(UInt16 refNum, Int32 *muted)
			  	THIS_LIB_TRAP(TrapModStateMuted);

extern Err ModStateLPM(UInt16 refNum, Int32 *LPM)
			  	THIS_LIB_TRAP(TrapModStateLPM);

extern Err ModMute(UInt16 refNum, Int32 boolean)
			  	THIS_LIB_TRAP(TrapModMute);

extern Err ModGetPhoneNumber(UInt16 refNum, char *phoneNumber)
			  	THIS_LIB_TRAP(TrapModGetPhoneNumber);
			  	
extern Err TelMakeCall(UInt16 refNum, char *phoneNumber, Int32 *status)
			  	THIS_LIB_TRAP(TrapTelMakeCall);
			  	
extern Err TelEndCall(UInt16 refNum, Int32 *status)
			  	THIS_LIB_TRAP(TrapTelEndCall);
			  	
extern Err TelAnswerCall(UInt16 refNum, Int32 *status)
			  	THIS_LIB_TRAP(TrapTelAnswerCall);

extern Err TelGenerateDTMF(UInt16 refNum, char *key, Int32 bLong, Int32 *status)
			  	THIS_LIB_TRAP(TrapTelGenerateDTMF);

extern Err TelGetCallInfo(UInt16 refNum, Int32 *status)
			  	THIS_LIB_TRAP(TrapTelGetCallInfo);

extern Err TelCISignalHist(UInt16 refNum, Int32 *signalHist)
			  	THIS_LIB_TRAP(TrapTelCISignalHist);

extern Err TelCICallFlags(UInt16 refNum, Int32 *callFlags)
				THIS_LIB_TRAP(TrapTelCICallFlags);
				
extern Err TelCICallerIDStatus(UInt16 refNum, Int32 *callerIDStatus)
				THIS_LIB_TRAP(TrapTelCICallerIDStatus);
				
extern Err TelCIDialingPaused(UInt16 refNum, Int32 *dialingPaused)
				THIS_LIB_TRAP(TrapTelCIDialingPaused);
				
extern Err TelCINumber(UInt16 refNum, char *number)
				THIS_LIB_TRAP(TrapTelCIPhoneNumber);
				
extern Err TelCITimeOfCall(UInt16 refNum, Int32 *timeOfCall)
				THIS_LIB_TRAP(TrapTelCITimeOfCall);
				
extern Err TelCICallDuration(UInt16 refNum, Int32 *callDuration)
				THIS_LIB_TRAP(TrapTelCICallDuration);
				
extern Err TelCIWaiting(UInt16 refNum, char *waiting)
				THIS_LIB_TRAP(TrapTelCIWaiting);
				
extern Err TelCIExt(UInt16 refNum, char *ext)
				THIS_LIB_TRAP(TrapTelCIExt);
				
extern Err TelCIErr(UInt16 refNum, Int32 *err)
				THIS_LIB_TRAP(TrapTelCIErr);
				
extern Err TelCICallType(UInt16 refNum, Int32 *callType)
				THIS_LIB_TRAP(TrapTelCICallType);
				
extern Err TelCIBaudRate(UInt16 refNum, Int32 *baudRate)
				THIS_LIB_TRAP(TrapTelCIBaudRate);

extern Err TelResumeDialing(UInt16 refNum)
			  	THIS_LIB_TRAP(TrapTelResumeDialing);

extern Err TelCancelPause(UInt16 refNum)
			  	THIS_LIB_TRAP(TrapTelCancelPause);

extern Err TelFormatNumber(UInt16 refNum, char *unformatted, Int32 flags, char *formatted) 
			  	THIS_LIB_TRAP(TrapTelFormatNumber);

extern Err TelGetDigit(UInt16 refNum, char *inChar, char *outChar) 
			  	THIS_LIB_TRAP(TrapTelGetDigit);

extern Err RegGetVersion(UInt16 refNum, double *version)
				THIS_LIB_TRAP(TrapRegGetVersion);

extern Err RegAddScheme(UInt16 refNum, char *scheme, char *creator, Int32 capFlags, Int32 *status)
				THIS_LIB_TRAP(TrapRegAddScheme);

extern Err RegRemoveScheme(UInt16 refNum, char *scheme, char *creator, Int32 *status)
				THIS_LIB_TRAP(TrapRegRemoveScheme);
				
extern Err RegEnableScheme(UInt16 refNum, char *scheme, char *creator, Int32 enable, Int32 *status)
				THIS_LIB_TRAP(TrapRegEnableScheme);

extern Err RegEnumSchemes(UInt16 refNum, Int32 number, char *scheme)
				THIS_LIB_TRAP(TrapRegEnumSchemes);

extern Err RegSchemeName(UInt16 refNum, char *name)
				THIS_LIB_TRAP(TrapRegSchemeName);
				
extern Err RegSchemeShortName(UInt16 refNum, char *shortName)
				THIS_LIB_TRAP(TrapRegSchemeShortName);

extern Err RegSchemeCreator(UInt16 refNum, char *creator)
				THIS_LIB_TRAP(TrapRegSchemeCreator);

extern Err RegSchemeFlags(UInt16 refNum, Int32 *flags)
				THIS_LIB_TRAP(TrapRegSchemeFlags);

extern Err RegSchemeEnabled(UInt16 refNum, Int32 *enabled)
				THIS_LIB_TRAP(TrapRegSchemeEnabled);

extern Err RegGetHandler(UInt16 refNum, char *scheme, char *creator)
				THIS_LIB_TRAP(TrapRegGetHandler);

extern Err RegProcessURL(UInt16 refNum, char *URL, Int32 *status)
				THIS_LIB_TRAP(TrapRegProcessURL);

extern Err RegProcessMailAddress(UInt16 refNum, char *firstName, char *lastName, char *address, Int32 *status)
				THIS_LIB_TRAP(TrapRegProcessMailAddress);

extern Err RegAddMacro(UInt16 refNum, char *URL, char *shortName, char *desc)
				THIS_LIB_TRAP(TrapRegAddMacro);
				
extern Err RegRemoveMacro(UInt16 refNum, char *URL)
				THIS_LIB_TRAP(TrapRegRemoveMacro);

extern Err RegEnumMacros(UInt16 refNum, Int32 number, char *URL)
				THIS_LIB_TRAP(TrapRegEnumMacros);

extern Err RegMacroDesc(UInt16 refNum, char *desc)
				THIS_LIB_TRAP(TrapRegMacroDesc);

extern Err RegMacroShortName(UInt16 refNum, char *shortName)
				THIS_LIB_TRAP(TrapRegMacroShortName);

extern Err RegSetHandlerName(UInt16 refNum, char *scheme, char *name, char *shortName, Int32 *status)
				THIS_LIB_TRAP(TrapRegSetHandlerName);

extern Err ProxyRegister(UInt16 refNum, Int32 uClass, Int32 uMask,
                Int32 nPriority, char *sCreator, Int32 *result)	
				THIS_LIB_TRAP(TrapProxyRegister);

extern Err ProxyUnregister(UInt16 refNum, Int32 uClass, Int32 uMask,
                           Int32 *result)	
				THIS_LIB_TRAP(TrapProxyUnregister);
				
extern Err ProxyUnregisterAll(UInt16 refNum)	
				THIS_LIB_TRAP(TrapProxyUnregisterAll);
				
extern Err ProxyCurrentApp(UInt16 refNum, Char *sCreator, Int32 *result)	
				THIS_LIB_TRAP(TrapProxyCurrentApp);

extern Err ProxyGetCallInfo(UInt16 refNum, Int32 *status)
			  	THIS_LIB_TRAP(TrapProxyGetCallInfo);

extern Err ProxyEventTime(UInt16 refNum, Int32 *sysTime)
			  	THIS_LIB_TRAP(TrapProxyEventTime);

extern Err ProxyClass(UInt16 refNum, Int32 *signalClass)
			  	THIS_LIB_TRAP(TrapProxyClass);

extern Err ProxySignal(UInt16 refNum, Int32 *signal)
			  	THIS_LIB_TRAP(TrapProxySignal);

extern Err StringDateTime(UInt16 refNum, 
                          UInt32 sysTime,
                          Int32 ToDateFormat,
                          Int32 ToTimeFormat,
                          Int32 AMPMFormat,
                          char *strDateTime)
				THIS_LIB_TRAP(TrapStringDateTime);


extern Err StringDate(UInt16 refNum, 
                      UInt32 sysTime,
                      Int32 ToDateFormat,
                      char *strDate)
				THIS_LIB_TRAP(TrapStringDate);

extern Err StringTime(UInt16 refNum, 
                      UInt32 sysTime,
                      Int32 ToTimeFormat,
                      Int32 AMPMFormat,
                      char *strTime)
				THIS_LIB_TRAP(TrapStringTime);

/*###################################################################
 #      S t a n d a r d ,  R E Q U I R E D    P r o t o t y p e s
 #
 #   You should not need to modify these prototypes.  Put your
 #   library's custom prototypes before these to separate your
 #   custom code from the standard, required code.  This way,
 #   the code you need to modify is easily found at the top of the
 #   file and you can "ignore" the standard, required, code at the
 #   end of the file.
 ###################################################################*/

extern Err THIS_LibOpen(UInt16 refNum)
				THIS_LIB_TRAP(sysLibTrapOpen);
				
extern Err THIS_LibClose(UInt16 refNum)
				THIS_LIB_TRAP(sysLibTrapClose);

extern Err THIS_LibSleep(UInt16 refNum)
				THIS_LIB_TRAP(sysLibTrapSleep);

extern Err THIS_LibWake(UInt16 refNum)
				THIS_LIB_TRAP(sysLibTrapWake);

// For loading the library in Palm OS Mac emulation mode
extern Err THIS_LibInstall(UInt16 refNum, SysLibTblEntryPtr entryP);

/*###################################################################*/

#ifdef __cplusplus 
}
#endif

#endif	// __THIS_LIB_H__

